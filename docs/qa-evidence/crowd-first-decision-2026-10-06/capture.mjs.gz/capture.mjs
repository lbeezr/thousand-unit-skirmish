// Explicit one paired fixture capture, hard stop185. No broad qualification or fix.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {gunzipSync,gzipSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';
import {createTemporalObserver as baselineObserver} from './baseline-observer.mjs';
import {createTemporalObserver as candidateObserver} from './candidate-observer.mjs';
const out=new URL('./',import.meta.url), sha=v=>createHash('sha256').update(typeof v==='string'||Buffer.isBuffer(v)?v:JSON.stringify(v)).digest('hex');
const roots={baseline:'/workspace/crowd-directed-join-baseline',candidate:'/workspace/crowd-directed-join-candidate'};
const heads={baseline:'31af0275698d369e83705771fdfa6983358a1742',candidate:'2882498c096e33549d5f4c52e7a176e5aacd2ed5'};
const source={};
for(const [label,root] of Object.entries(roots)) {
 assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),heads[label]);
 assert.equal(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim(),'');
 source[label]={head:heads[label],sha256:{}};
 for(const name of ['server.mjs','src/unit-crowd-steering.mjs','src/unit-movement.mjs','src/crowd-wait-lease.mjs','src/crowd-parked-contour.mjs','scripts/pathing-replay-fixture.mjs'])
  source[label].sha256[name]=sha(await readFile(root+'/'+name));
}
const input=JSON.parse(gunzipSync(await readFile(roots.baseline+'/docs/qa-evidence/ordinary-move-static-clearance-2026-10-04/substeps.json.gz'))).records.find(r=>r.id==='forest-opposing-box-16').initialCheckpoint;
const inputHash=sha(input);assert.equal(inputHash,'aba4ea83b1a8fccf7ebbae1f80e6bf78663e22ab0d09cf2483a95b111629da6a');
const report={schema:1,status:'reserved',source,inputCheckpointSha256:inputHash,case:'forest-opposing-box-16',maximumJourneyTick:185,
 originalJourneyDeadline:900,originalFairnessMaximumGap:150,captureAttempt:2,priorFailure:{artifact:"attempt-1/failure.json",baselineJourneyTick:1,candidateJourneyTicksExecuted:0,reason:"missing generated server admission-hook import"},
 publicationScope:'Only fixture map/commands and whitelisted movement actors/controller/query states; no raw checkpoint.',matchedCalls:0,matchingTickHashes:[],firstDivergence:null};
await writeFile(new URL('capture-reservation.json',out),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
Object.assign(process.env,{RTS_MAP:'maps/open-field.json',RTS_GAME_MODE:'pvp',RTS_PREGAME:'0',RTS_MOVE_PLANNING_TURNS_PER_TICK:'0'});delete process.env.RTS_MATCH_STATE_PATH;
const selected=input.state.units.filter(u=>u.kind==='infantry'||u.kind==='scout').map(u=>u.id);
assert.equal(selected.length,32);
const stop=Object.assign(new Error('FIRST_PAIRED_DIVERGENCE_CAPTURED'),{boundedStop:true});
let b,c,bframes=[],ci=0,journeyTick=0,armed=null,latestCandidate=null,previousMatched=null;
const semanticResult=value=>{
 if(!value||typeof value!=='object')return value;
 if(Array.isArray(value))return value.map(semanticResult);
 return Object.fromEntries(Object.entries(value).filter(([k])=>!['crowdControl','crowd','diagnostics'].includes(k)).map(([k,v])=>[k,semanticResult(v)]));
};
function fingerprint(frame) {
 return {actor:frame.actor,input:semanticResult(frame.input),query:frame.query,queryVisits:frame.queryVisits,bodies:frame.bodies,
  hostEntry:frame.events.find(e=>e.type==='host-entry'),claimants:frame.events.filter(e=>e.type==='claimant'),
  priority:frame.events.find(e=>e.type==='priority'),selection:semanticResult(frame.selection),result:semanticResult(frame.result),afterState:frame.afterState};
}
function firstDifference(a,b,path='$') {
 if(JSON.stringify(a)===JSON.stringify(b))return null;
 if(a&&b&&typeof a==='object'&&typeof b==='object') {
  for(const key of new Set([...Object.keys(a),...Object.keys(b)])){
   const diff=firstDifference(a[key],b[key],path+'.'+key);if(diff)return diff;
  }
 }
 return {path,baseline:a??null,candidate:b??null};
}
const arm=(bf,cf,reason)=>{
 if(armed)return;
 armed={journeyTick,productionTick:cf.tick,serialCall:ci-1,actor:cf.actor.id,reason,baseline:bf,candidate:cf,previousMatched};
 console.log(JSON.stringify({firstDivergence:journeyTick,productionTick:cf.tick,serialCall:ci-1,actor:cf.actor.id,reason}));
};
try {
 b=await baselineObserver(structuredClone(input.mapDefinition),{actorId:selected});
 c=await candidateObserver(structuredClone(input.mapDefinition),{actorId:selected});
 for(const f of [b,c]) {
  assert.ok(f.replay.validate(structuredClone(input)));f.replay.restore(structuredClone(input));
 }
 report.map=structuredClone(input.mapDefinition);report.selectedActorIds=selected;
 report.navigationMask=Array.from({length:report.map.width*report.map.height},(_,cell)=>b.replay.isWalkable(cell));
 report.elevationLevels=Array.from(b.replay.levels);assert.ok(report.elevationLevels.every(x=>x===0));
 report.navigationMaskSha256=sha(report.navigationMask);
 assert.equal(report.navigationMaskSha256,'39db278dc36a201c2a5c73fde5d3aca5746d7a6089be783570d682604f40f751');
 assert.deepEqual(report.navigationMask,Array.from({length:report.navigationMask.length},(_,cell)=>c.replay.isWalkable(cell)));
 report.commands=[];
 for(const team of [0,1]) {
  const own=b.replay.units.filter(u=>selected.includes(u.id)&&u.team===team);
  const command={type:'move',ids:own.map(u=>u.id),unitGenerations:own.map(u=>u.generation),x:team?-12.5:12.5,z:.5,formation:'box'};
  for(const f of [b,c]) {
   const notices=f.replay.order(team,structuredClone(command));f.replay.drain();
   assert.ok(notices.some(n=>/MOVE ORDER|PLANNING MOVE/.test(n.message)));
   assert.ok(!notices.some(n=>/REJECTED|FAILED|UNREACHABLE/.test(n.message)));
  }
  report.commands.push({team,command});
 }
 report.initialProductionTick=b.replay.tick;assert.equal(b.replay.tick,c.replay.tick);
 report.initialSelectedStatesSha256=sha(b.replay.units.filter(u=>selected.includes(u.id)).map(b.observed.replayActor));
 assert.equal(report.initialSelectedStatesSha256,sha(c.replay.units.filter(u=>selected.includes(u.id)).map(c.observed.replayActor)));
 b.observed.setReplaySink(frame=>{frame.admissions=[];frame.serialCall=bframes.length;bframes.push(frame);},(actor,admission,finalized)=>{
  const frame=bframes.at(-1);if(frame?.actor.id===actor.id)frame.admissions.push({actor,admission:admission??null,finalized});
 });
 c.observed.setReplaySink(frame=>{
  frame.admissions=[];frame.serialCall=ci;latestCandidate=frame;
  const bf=bframes[ci++];assert.ok(bf,'baseline serial call exists');
  const diff=firstDifference(fingerprint(bf),fingerprint(frame));
  if(diff)arm(bf,frame,diff);else{report.matchedCalls++;previousMatched={journeyTick,productionTick:frame.tick,serialCall:ci-1,actor:frame.actor.id,fingerprintSha256:sha(fingerprint(frame))};}
 },(actor,admission,finalized)=>{
  const frame=latestCandidate;if(frame?.actor.id!==actor.id)return;
  const entry={actor,admission:admission??null,finalized};frame.admissions.push(entry);
  const bf=bframes[frame.serialCall],expected=bf.admissions[frame.admissions.length-1];
  if(!armed){const diff=firstDifference(expected,entry);if(diff)arm(bf,frame,{...diff,path:'$.admission'+diff.path.slice(1)});}
  if(armed&&armed.candidate===frame)throw stop;
 });
 for(journeyTick=1;journeyTick<=185;journeyTick++) {
  bframes=[];ci=0;latestCandidate=null;b.replay.step();
  try {c.replay.step();}catch(error){if(error!==stop)throw error;break;}
  if(armed)break;
  assert.equal(ci,bframes.length,'paired calls match before divergence');
  const poses=f=>f.replay.units.map(u=>[u.id,u.generation,u.x,u.z,u.hp,u.orderRevision,u.pathIndex,[...u.path],u.moveGoalCell,u.movePlanningPending]);
  assert.deepEqual(poses(b),poses(c),'all actor state remains paired before first call divergence');
  report.matchingTickHashes.push({journeyTick,productionTick:b.replay.tick,posesSha256:sha(poses(b)),calls:ci});
  b.observed.drainReplayFrames();c.observed.drainReplayFrames();
 }
 report.status=armed?'captured':'no-divergence-within-bound';report.lastJourneyTick=Math.min(journeyTick,185);
 if(armed) {
  report.firstDivergence=armed;
  const steps=f=>f.replay.landSteps.filter(s=>s.id===armed.actor&&s.from.x===armed.candidate.actor.x&&s.from.z===armed.candidate.actor.z).map(({neighbours,...s})=>s);
  report.firstDivergence.baselineSubsteps=steps(b);report.firstDivergence.candidateSubsteps=steps(c);
  report.stopBoundary='Candidate halted at the first differing call admission (immediately after actual position write or no-write refusal). Baseline completed that same fixed tick to supply serial reference calls; neither instance advanced to a following journey tick.';
 }
 report.observerSha256={};for(const file of ['baseline-observer.mjs','candidate-observer.mjs','capture.mjs','prepare.py'])report.observerSha256[file]=sha(await readFile(new URL(file,out)));
 const encoded=JSON.stringify(report)+'\n';
 assert.ok(!/(?:seatSessions|tokenHash|matchId|recoveryToken|checkpointSequence)/.test(encoded),'public-safe schema');
 await writeFile(new URL('first-decision.json',out),encoded);await writeFile(new URL('first-decision.json.gz',out),gzipSync(encoded,{level:9}));
 console.log(JSON.stringify({status:report.status,lastJourneyTick:report.lastJourneyTick,matchedCalls:report.matchedCalls,sha256:sha(encoded),compressedSha256:sha(await readFile(new URL('first-decision.json.gz',out)))}));
} catch(error) {
 report.status='failed';report.error=String(error.stack??error);report.lastJourneyTick=journeyTick;
 await writeFile(new URL('failure.json',out),JSON.stringify(report,null,2)+'\n');throw error;
} finally {await c?.dispose();await b?.dispose();}
