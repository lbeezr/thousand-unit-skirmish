from pathlib import Path
import json
p=Path(__file__).parent
base=Path('/workspace/crowd-directed-join-baseline')
s=(base/'scripts/construction-temporal-observer.mjs').read_text()
s=s.replace("const root = fileURLToPath(new URL('..', import.meta.url));", "const root = SOURCE_ROOT;", 1)
s=s.replace('actorId = 75', 'actorId = [4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39]')
# Derive the actual retained roster in the driver; this array is only a default.
s=s.replace('unit.id !== ${actorId}', '!${JSON.stringify(actorId)}.includes(unit.id)')
s=s.replace('unit.id === ${actorId}', '${JSON.stringify(actorId)}.includes(unit.id)')
s=s.replace('args.unit.id === ${actorId}', '${JSON.stringify(actorId)}.includes(args.unit.id)')
# The previous replacement can match within args.unit; guard against malformed output.
s=s.replace('args.${JSON.stringify(actorId)}.includes(unit.id)', '${JSON.stringify(actorId)}.includes(args.unit.id)')
s=s.replace('replayQueryVisit, replayQuery, replayNote }', 'replayQueryVisit, replayQuery, replayNote, replayAdmission }')
s=s.replace("  return source + `", "  source = observePriorityClaimants(source);\n  return source + `")
s=s.replace("let replayFrames = [];", "let replayFrames = [], replaySink = null, admissionSink = null;\nexport function setReplaySink(sink, admissions) { replaySink = sink; admissionSink = admissions; }\nexport function replayAdmission(unit, admission, finalized) { admissionSink?.(replayActor(unit), admission, finalized); }")
s=s.replace('  replayFrames.push(replayActive); replayActive = null;', '  replayFrames.push(replayActive); const completed = replayActive; replayActive = null; replaySink?.(completed);')
s=s.replace("  replayHostStart(unit, tickNumber, navigationRevision, movePlanningEpoch);\\n'", "  replayHostStart(unit, tickNumber, navigationRevision, movePlanningEpoch);\\n'\n    + '  replayNote(\"host-entry\", { remainingStep, allowLocalDetour });\\n'")
# Replay admission hook is outside the original single-team observer guard; every real admission is seen.
s=s.replace("    adapter += `", "    adapter = replace(adapter, 'function observeReplayMovementAdmission(unit, admission, finalized = true) {',\n      'function observeReplayMovementAdmission(unit, admission, finalized = true) {\\n  replayAdmission(unit, admission, finalized);');\n    adapter = \"import { replayAdmission } from '\" + moduleUrl + \"';\\n\" + adapter;\n    adapter += `")
# Add exact, passive per-claimant observations while preserving short circuit evaluation.
s += '''
function observePriorityClaimants(source) {
  const first = '  const yieldingToPeer = noProgressTicks >= 30 && neighbors.some(other => ';
  const end = "\\n  replayPhase = 'recovery';";
  const start = source.indexOf(first), finish = source.indexOf(end, start);
  if (start < 0 || finish < 0) throw Error('claimant observation boundary changed');
  const original = source.slice(start, finish);
  if (!original.endsWith(');')) throw Error('claimant expression boundary changed');
  const expression = original.slice(first.length, -2);
  let replacement = first.slice(0,-'other => '.length) + 'other => { const claims = ' + expression
    + "; replayNote('claimant', { id: other.id, claims }); return claims; });";
  if (replacement.includes('!parallelWaypointStep(other)')) replacement = replacement.replace('!parallelWaypointStep(other)',
    "!replayClaimPredicate('parallel-waypoint', other, parallelWaypointStep(other))");
  if (replacement.includes('!directedJoinStep(other)')) replacement = replacement.replace('!directedJoinStep(other)',
    "!replayClaimPredicate('directed-join', other, directedJoinStep(other))");
  source = source.slice(0,start) + replacement + source.slice(finish);
  return source + `\\nfunction replayClaimPredicate(predicate, other, result) {
    replayNote('claim-predicate', { predicate, id: other.id, result }); return result;
  }\\n`;
}
'''
for label in ['baseline','candidate']:
    root=Path('/workspace/crowd-directed-join-'+label)
    (p/(label+'-observer.mjs')).write_text(s.replace('SOURCE_ROOT',json.dumps(str(root))))
print('Prepared observer copies; no game fixture created.')
# Preserve original executor step budget separately from selector's bounded input.
for label in ['baseline','candidate']:
    f=p/(label+'-observer.mjs')
    text=f.read_text()
    before="    + '  return replayHostEnd(unit, productionGetMoveVector(unit, remainingStep, allowLocalDetour));"
    after=r'''    + '  replayNote("host-entry", { remainingStep, allowLocalDetour });\\n'
    + '  return replayHostEnd(unit, productionGetMoveVector(unit, remainingStep, allowLocalDetour));'''
    assert text.count(before)==1
    text=text.replace(before,after)
    f.write_text(text)
