import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {setCase} from './gate-fixed-observer.mjs';
import {runQueuedGateCase} from './compatible-gate-case.mjs';
const output='/workspace/scratch/crowd-541-qualification/candidate',records=JSON.parse(await readFile(`${output}/fixed-results-before-gate.json`));
for(const team of [0,1]){
 const name=`gate-seat${team}`;setCase({name,team,mode:'closed-gate'});let result,error;
 try {
  result=await runQueuedGateCase({team,observePauses:true,tracePhysical:true,captureInput:value=>writeFile(`${output}/${name}-close-input.json`,JSON.stringify(value)),
   captureFinal:value=>writeFile(`${output}/${name}-checkpoint.json`,JSON.stringify(value))});
  assert.equal(result.distinctGoals,64);assert.equal(result.pauseObservations.length,8);
  assert.ok(result.pauseObservations.every(row=>row.id>=team*68&&row.id<(team+1)*68));
  assert.ok(result.pauseObservations.every(row=>Object.keys(row).join('|')==='id|holding|planningPending|performingAction|routeActive|decision|admission|positionChanged|motionWindow'));
  assert.ok(result.pauseObservations.every(row=>['vector-wait','vector-proposal','static-proposal-rejected','no-vector-proposal','unobserved'].includes(row.decision)&&!row.routeActive));
  assert.ok(result.maxPathLength<160);
 }catch(e){error={message:e.message,stack:e.stack,actual:e.actual,expected:e.expected};}
 const observed=JSON.parse(await readFile(`${output}/${name}-summary.json`));
 records.push({name,passed:!error,result,error,observed});await writeFile(`${output}/fixed-results.json`,JSON.stringify(records,null,2)+'\n');
 console.log(JSON.stringify({name,passed:!error,ticks:result?.ticks,arrived:observed.arrived,entitlement:observed.entitlement,physical:observed.physical,error}));
}
process.exitCode=records.every(r=>r.passed)?0:1;
