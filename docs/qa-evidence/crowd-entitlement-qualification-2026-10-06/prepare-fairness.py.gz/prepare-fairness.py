from pathlib import Path
import re,json,hashlib
q=Path(__file__).parent
for label in ['baseline','candidate']:
 root=Path('/workspace/crowd-entitlement-qualification-'+label);out=q/label
 factory=f"""import {{createPathingReplayFixture as original}} from '{(root/'scripts/pathing-replay-fixture.mjs').as_uri()}';
import * as crowd from '{(root/'src/unit-crowd-steering.mjs').as_uri()}';
import {{observeEntitlements}} from '../entitlement-observer.mjs';
export const entitlement=observeEntitlements(crowd);
export const maximumWork={{}};
export function resetObservations(){{entitlement.reset();for(const key in maximumWork)delete maximumWork[key];}}
export async function createPathingReplayFixture(map,options){{
 const f=await original(map,options),r=f.replay,step=r.step.bind(r);
 r.step=(...args)=>{{const result=step(...args);entitlement.afterTick(r);
 for(const u of r.units){{const w=crowd.crowdSteeringRecord?.(u)?.execution?.work;
 if(w)for(const [k,v]of Object.entries(w))if(Number.isFinite(v))maximumWork[k]=Math.max(maximumWork[k]??0,v);}}
 return result;}};return f;
}}
"""
 (out/'fairness-observer.mjs').write_text(factory)
 for script in ['land-body-clearance-fixture.mjs','crowd-body-journeys.mjs']:
  s=(root/'scripts'/script).read_text();s=s.replace("from './pathing-replay-fixture.mjs'","from './fairness-observer.mjs'")
  s=re.sub(r"from '(\.?\.?/[^']+)'",lambda m:"from '"+((out/m[1]).resolve().as_uri() if m[1]=='./fairness-observer.mjs' else (root/'scripts'/m[1]).resolve().as_uri())+"'",s)
  (out/script).write_text(s)
