import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const out=new URL('./',import.meta.url),json=async n=>JSON.parse(await readFile(new URL(n,out))),sha=v=>createHash('sha256').update(v).digest('hex');
const heads={baseline:'a71fcb46acb767c60cc26b46d2f1d04c7ab1d77a',candidate:'30a2d7099527fef17d60f53cd87456f1b54883fb'};
const sources={},runs={},registered={};
for(const label of ['baseline','candidate']) {
 const root='/workspace/crowd-entitlement-qualification-'+label,git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
 assert.equal(git('rev-parse','HEAD'),heads[label]);assert.equal(git('status','--porcelain'),'');
 sources[label]={head:heads[label],clean:true,sourceHashes:{}};
 for(const name of ['server.mjs','src/unit-crowd-steering.mjs','src/unit-movement.mjs','src/crowd-wait-lease.mjs','scripts/pathing-replay-fixture.mjs','scripts/dynamic-wall-pathing.mjs','scripts/queued-gate-pathing.mjs','scripts/land-body-clearance-fixture.mjs','scripts/crowd-body-journeys.mjs','scripts/crowd-body-journeys.test.mjs','scripts/forest-gap.test.mjs'])sources[label].sourceHashes[name]=sha(await readFile(root+'/'+name));
 if(label==='candidate')sources[label].sourceHashes['src/crowd-moving-entitlement.mjs']=sha(await readFile(root+'/src/crowd-moving-entitlement.mjs'));
 runs[label]=await json(label+'/fixed-results.json');assert.equal(runs[label].length,8);
 const t=await readFile(new URL(label+'-journeys.tap',out),'utf8');registered[label]={};
 for(const field of ['tests','pass','fail']){const matches=[...t.matchAll(new RegExp('(?:#|ℹ) '+field+' (\\d+)','g'))];assert.ok(matches.length,'completed registered check '+field);registered[label][field]=Number(matches.at(-1)[1]);}
 registered[label].failures=[...new Set([...t.matchAll(/^✖ (.+?) \([\d.]+ms\)$/gm)].map(x=>x[1]))];
}
for(const name of ['scripts/dynamic-wall-pathing.mjs','scripts/queued-gate-pathing.mjs','scripts/pathing-replay-fixture.mjs','scripts/land-body-clearance-fixture.mjs','scripts/crowd-body-journeys.mjs','scripts/crowd-body-journeys.test.mjs','scripts/forest-gap.test.mjs'])assert.equal(sources.baseline.sourceHashes[name],sources.candidate.sourceHashes[name],name+' original harness unchanged');
const fixed=runs.baseline.map(b=>{
 const c=runs.candidate.find(r=>r.name===b.name);assert.ok(c);assert.equal(b.observed.seed,881);assert.equal(c.observed.seed,881);assert.equal(b.observed.mapSha256,c.observed.mapSha256);
 const row=r=>({passed:r.passed,arrived:r.observed.arrived,queuedActors:r.observed.queued,queuedLegs:r.observed.queuedLegs,pending:r.observed.pending,
  elapsedTicks:r.result?.ticks??(r.name.startsWith('wall')?r.observed.tick:2700),absoluteTick:r.observed.tick,deadline:2700,
  clock:r.name.startsWith('gate')?'relative to gate close':'absolute simulation tick',
  completionError:r.error?{message:r.error.message,actual:r.error.actual,expected:r.error.expected}:null,
  militaryPhysical:r.observed.physical,workerPhysical:r.observed.workerPhysical,controlMax:r.observed.controlMax,
  repairSamples:r.observed.repairSamples.length,maxWaitAge:r.observed.controlMax.waitAge??0,
  actorArrivalsAndQueueHandoffs:r.observed.handoffs,distinctGoals:r.observed.distinctGoals,
  entitlement:r.observed.entitlement});
 return {name:b.name,mapSha256:b.observed.mapSha256,baseline:row(b),candidate:row(c)};
});
const bf=await json('baseline-fairness.json'),cf=await json('candidate-fairness.json');
const fairness=bf.records.map(b=>{
 const c=cf.records.find(r=>r.name===b.name);assert.ok(c);assert.equal(b.inputHash,c.inputHash);assert.equal(b.navigationHash,c.navigationHash);
 const row=r=>({passed:r.passed,arrived:r.arrived,lastSeatArrivals:r.lastArrival,arrivalGap:r.arrivalGap,finalTick:r.finalTick,staticContacts:r.staticContacts,pairContacts:r.pairContacts,
  controls:r.controls,maximumWork:r.maximumWork,entitlement:r.entitlement});
 return {name:b.name,identicalInputSha256:b.inputHash,deadline:900,maximumSeatGap:150,baseline:row(b),candidate:row(c)};
});
const aggregate=label=>{
 const rows=fixed.map(r=>r[label]);const sum=(field,key)=>rows.reduce((n,r)=>n+(r[field]?.[key]??0),0);
 return {passedCases:rows.filter(r=>r.passed).length,totalCases:8,selectedMilitarySubsteps:sum('militaryPhysical','selectedSubsteps'),
  militaryStaticContactSteps:sum('militaryPhysical','staticContactSteps'),militaryNewPairContactSteps:sum('militaryPhysical','newPairContactSteps'),militaryIllegalInheritedEscapeSteps:sum('militaryPhysical','illegalInheritedEscapeSteps'),
  workerStaticContactSteps:sum('workerPhysical','staticContactSteps'),workerNewPairContactSteps:sum('workerPhysical','newPairContactSteps'),workerStepsRejectedByGenericBodySweep:sum('workerPhysical','illegalInheritedEscapeSteps'),
  everyInactiveMilitaryRosterPreserved:rows.every(r=>r.militaryPhysical.inactiveMilitaryPreserved===64),
  maxNeighbors:Math.max(...rows.map(r=>r.controlMax.neighbors??0)),maxSelectorProposals:Math.max(...rows.map(r=>r.controlMax.proposals??0)),
  maxActualSharedAdmissions:Math.max(...rows.map(r=>r.controlMax['shared:proposals']??0)),
  grantPublications:rows.reduce((n,r)=>n+(r.entitlement?.counts?.publications??0),0),grantConsumptions:rows.reduce((n,r)=>n+(r.entitlement?.counts?.consumptions??0),0),grantCancellations:rows.reduce((n,r)=>n+(r.entitlement?.counts?.cancellations??0),0),outstandingReservations:rows.reduce((n,r)=>n+(r.entitlement?.outstanding??0),0)};
};
const aggregates={baseline:aggregate('baseline'),candidate:aggregate('candidate')};
const newlyFailing=fixed.filter(r=>r.baseline.passed&&!r.candidate.passed).map(r=>r.name);
const newFairnessFailures=fairness.filter(r=>r.baseline.passed&&!r.candidate.passed).map(r=>r.name);
const fullPass=fixed.every(r=>r.candidate.passed)&&fairness.every(r=>r.candidate.passed)&&registered.candidate.fail===0;
const receipt={schema:1,task:'Independent original-contract PR541 qualification; no competing implementation or merge',node:process.version,sources,
 originalContract:{seed:881,fixedJourneys:8,fixedDeadline:2700,fairnessDeadline:900,maximumSeatGap:150,identicalMatchedFairnessInputs:true,originalCaseBodiesAndAssertionsUnchanged:true},
 aggregate:aggregates,fixed,fairness,registeredJourneys:registered,newlyFailing,newFairnessFailures,
 verdict:fullPass?'Passes the executed original contracts.':'Does not pass the full original-contract qualification; retain draft/unmerged candidate and explicit failed evidence.',
 regressionVerdict:newlyFailing.length||newFairnessFailures.length?'New failing contracts observed.':'No loss of a baseline-passing eight-case journey or matched fairness case.',
 activationVerdict:aggregates.candidate.grantPublications>0&&aggregates.candidate.grantConsumptions>0?'Named-step integration actually publishes and consumes in original journeys; not a global no-op.':'No successful named-step activation observed; passing cases alone do not qualify activation.',
 ownerNextStep:'Core01a107ba retains the candidate and any narrowing/retirement; parent receives this independent qualification. No merge by qualifier.',
 retainedRejection:'PR529 remains rejected; its old qualification92-file seal is preserved.',
 gateObserverCompatibility:{canonicalCandidateAdapter:'Fails before fixture creation: stale observeMovement match for combined Worker/capsule steering/fallback guards.',
  originalFailure:'candidate-gate-observer-incompatibility.json',readOnlyCompatibility:'gate-observer-compatibility.json',
  changes:'Private test adapter matches two existing combined guards; original terminal guard retained; unchanged Boolean evaluation/call order/break; truthful body-or-capsule-wait observation.',
  scope:'Six completed wall cases not repeated. Only the two previously unstarted candidate gate cases run through compatible observer. All original gate assertions, actions and deadlines unchanged.',
  remainingOwner:'Core must update its canonical observation boundaries; qualifier makes no production/source edit.'},
 cancellationCoverage:'Zero issued-grant cancellations observed in these original journeys. This batch does not exercise or newly qualify cancellation handling.',
 limits:['Fixed-tick production-authority CPU replay with canonical planning drains; no native scheduling, CPU capacity, pack, served/deployed or rendered proof.',
 'Fixed journeys retain original maps/seed/actions and separate actual fresh generations. Only fairness cases claim identical full checkpoints; no identity normalization.',
 'Successful service counts come from real publish/finish return values after unchanged host finalized receipts; refused publication attempts are not issued grants.',
 'Cancellations count only issued reservations retired by actual take/finish, slot replacement/navigation invalidation or expiry. Request refusal is not grant cancellation.',
 'Military static/new-pair contacts and legal inherited escape are separate from Worker writes. Generic Worker sweep diagnosis does not establish universal caller-body safety.',
 'Observed repair/wait/progress values do not grant finite liveness to unfinished actors. No gates, deadlines, fairness assertions, source or caller policies were changed.']};
assert.ok(!/(?:seatSessions|tokenHash|matchId|recoveryToken|checkpointSequence)/.test(JSON.stringify(receipt)),'public-safe summary');
await writeFile(new URL('receipt.json',out),JSON.stringify(receipt,null,2)+'\n');
const paths=[];async function walk(url,prefix=''){for(const e of await readdir(url,{withFileTypes:true})){const name=prefix+e.name;if(e.isDirectory())await walk(new URL(e.name+'/',url),name+'/');else if(!['evidence-seal.json','report.log'].includes(e.name))paths.push(name);}}
await walk(out);const seal={};for(const name of paths.sort())seal[name]=sha(await readFile(new URL(name,out)));await writeFile(new URL('evidence-seal.json',out),JSON.stringify(seal,null,2)+'\n');
console.log(JSON.stringify({aggregate:aggregates,fixed:fixed.map(r=>({name:r.name,baseline:[r.baseline.arrived,r.baseline.elapsedTicks],candidate:[r.candidate.arrived,r.candidate.elapsedTicks],candidateGrants:r.candidate.entitlement?.counts})),fairness:fairness.map(r=>({name:r.name,baseline:r.baseline.lastSeatArrivals,candidate:r.candidate.lastSeatArrivals,candidateGrantCount:r.candidate.entitlement?.counts?.publications??0})),registered,newlyFailing,newFairnessFailures,verdict:receipt.verdict,activation:receipt.activationVerdict,sealedFiles:paths.length},null,2));
