// Read-only instrumentation of exported protocol methods in the actual module instance.
// No branch, result, argument, actor, controller or time is changed.
export function observeEntitlements(module) {
 const p=module.crowdMovingEntitlement;
 if(!p)return {supported:false,reset(){},afterTick(){},summary(){return {supported:false,reason:'baseline has no live entitlement instance'};}};
 const methods=['request','publish','prepareIngress','finishIngress','take','finish'];
 let counts,active,events,nextId,ids;
 const reset=()=>{counts={};active=new Map();events=[];nextId=1;ids=new WeakMap();};reset();
 const event=(type,r,extra={})=>{if(events.length<120)events.push({type,reservation:ids.get(r)??null,owner:r?.owner?.id,winner:r?.winner?.id,tick:r?.tick,...extra});};
 const cancel=(r,reason,tick)=>{const row=active.get(r);if(!row||row.status!=='pending')return;row.status='cancelled';counts.cancellations=(counts.cancellations??0)+1;counts['cancel:'+reason]=(counts['cancel:'+reason]??0)+1;event('cancelled',r,{reason,observedTick:tick});};
 for(const name of methods) {
  const original=p[name];
  p[name]=function(...args) {
   const unit=args[0],before=this.reservation(unit);
   const c=args[{request:4,publish:3,prepareIngress:2,finishIngress:2,take:1,finish:2}[name]];
   counts[name+'Calls']=(counts[name+'Calls']??0)+1;
   const result=Reflect.apply(original,this,args);
   counts[name+(result?'Accepted':'Refused')]=(counts[name+(result?'Accepted':'Refused')]??0)+1;
   if(name==='publish'&&result){ids.set(result,nextId++);active.set(result,{status:'pending',nav:c.nav,epoch:c.epoch});counts.publications=(counts.publications??0)+1;event('published',result,{from:{...result.from},to:{...result.to}});}
   if(name==='finishIngress'&&result)event('ingress-committed',this.state(unit)?.lease?.reservation,{actor:unit.id,observedTick:c.tick});
   if(name==='take'&&result)event('service-admitted',before,{observedTick:c.tick});
   if(name==='finish'&&before){if(result){const row=active.get(before);if(row?.status==='pending'){row.status='consumed';counts.consumptions=(counts.consumptions??0)+1;event('consumed',before,{observedTick:c.tick});}}else cancel(before,'finish-refused',c.tick);}
   if(name==='take'&&before&&!this.reservation(unit))cancel(before,'take-refused',c.tick);
   return result;
  };
 }
 return {supported:true,reset,afterTick(r){for(const [reservation,row] of active){if(row.status!=='pending')continue;
   if(p.reservation(reservation.owner)!==reservation)cancel(reservation,'slot-cleared-or-replaced',r.tick);
   else if(r.navigationRevision!==row.nav)cancel(reservation,'navigation-invalidated',r.tick);
   else if(r.tick>reservation.tick+1)cancel(reservation,'expired',r.tick);
  }},summary(){return {supported:true,counts:{publications:0,consumptions:0,cancellations:0,...counts},outstanding:[...active.values()].filter(r=>r.status==='pending').length,events};}};
}
