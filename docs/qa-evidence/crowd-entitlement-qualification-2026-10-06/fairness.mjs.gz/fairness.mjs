import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root=process.argv[2],label=process.argv[3],at=name=>import(new URL('./'+label+'/'+name,import.meta.url));
const {LAND_BODY_CASES,runLandBodyCase}=await at('land-body-clearance-fixture.mjs');
const {runCrowdPassageJourney}=await at('crowd-body-journeys.mjs');
const {entitlement,resetObservations,maximumWork}=await at('fairness-observer.mjs');
const retained=JSON.parse(gunzipSync(await readFile(root+'/docs/qa-evidence/ordinary-move-static-clearance-2026-10-04/substeps.json.gz')));
const records=[];
for(const name of ['forest-opposing-box-16','bridge','gate']){
 resetObservations();const spec=LAND_BODY_CASES.find(s=>s.id===name);
 const initial=spec?retained.records.find(r=>r.id===name).initialCheckpoint:JSON.parse(await readFile(new URL('./retained-'+name+'-input.json',import.meta.url)));
 let run,error;
 try {run=spec?await runLandBodyCase(spec,{initialCheckpoint:initial,maxTicks:900}):await runCrowdPassageJourney({scene:name,group:16,ownerTeam:0,mirror:false,initialCheckpoint:initial});}
 catch(e){error={message:e.message,stack:e.stack};}
 const actors=run?.actors??run?.states??[];
 const lastArrival=[0,1].map(team=>actors.filter(u=>u.team===team).every(u=>u.arrivalTick!==null)?Math.max(...actors.filter(u=>u.team===team).map(u=>u.arrivalTick)):null);
 const arrivalGap=lastArrival.every(v=>v!==null)?Math.abs(lastArrival[0]-lastArrival[1]):null;
 const controls={allArrive:run?.arrived===32,staticClear:(run?.staticContactSteps??run?.staticContacts)===0,bodyClear:(run?.pairContactSteps??run?.pairContacts)===0,
  fairness:arrivalGap!==null&&arrivalGap<=150,
  boundedRepair:actors.every(u=>(u.finalRevision??u.orderRevision)-u.initialRevision<=10),
  boundedProgress:spec?null:actors.every(u=>u.crossingTick>0&&u.maxNoProgressTicks<=360&&u.publishedRouteChanges<=11),
  sharedWork:(maximumWork.proposals??0)<=128};
 const row={name,arrived:run?.arrived??null,actors,lastArrival,arrivalGap,originalDeadline:900,originalMaximumGap:150,
  staticContacts:run?.staticContactSteps??run?.staticContacts??null,pairContacts:run?.pairContactSteps??run?.pairContacts??null,
  inputHash:run?.initialCheckpointSha256??run?.inputSha256??null,navigationHash:run?.navigationMaskSha256??null,finalTick:run?.ticks??null,
  controls,error,passed:!error&&Object.values(controls).every(v=>v!==false),entitlement:entitlement.summary(),maximumWork:{...maximumWork}};
 records.push(row);await writeFile(new URL('./'+label+'-fairness.json',import.meta.url),JSON.stringify({root,label,records},null,2)+'\n');
 console.log(JSON.stringify({...row,actors:actors.length,entitlement:{supported:row.entitlement.supported,counts:row.entitlement.counts,outstanding:row.entitlement.outstanding}}));
}
process.exitCode=records.every(r=>r.passed)?0:1;
