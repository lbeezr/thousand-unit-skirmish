import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createPathingReplayFixture as original} from '/workspace/crowd-entitlement-qualification-baseline/scripts/pathing-replay-fixture.mjs';
import {sweptStaticBodyContacts,sweptBodyPairMargin} from '/workspace/crowd-entitlement-qualification-baseline/scripts/land-body-clearance.mjs';
import {LAND_CLEARANCE_PROFILE} from '/workspace/crowd-entitlement-qualification-baseline/src/unit-movement.mjs';
import * as crowd from 'file:///workspace/crowd-entitlement-qualification-baseline/src/unit-crowd-steering.mjs';
import {observeEntitlements} from '../entitlement-observer.mjs';
const entitlement=observeEntitlements(crowd);
import {canTraverseCrowdBodySegment} from '/workspace/crowd-entitlement-qualification-baseline/src/unit-crowd-steering.mjs';
const output='/workspace/scratch/crowd-541-qualification/baseline';
let context;
export function setCase(value){context=value;}
export async function createPathingReplayFixture(map,options){
  entitlement.reset();
  const c={...context},f=await original(map,{...options,traceLandSteps:true,
    traceActorIds:Array.from({length:64},(_,i)=>c.team*68+4+i),traceCrowdSteps:true});
  const r=f.replay,step=r.step.bind(r),dispose=f.dispose.bind(f),trace=[];
  const selected=r.units.filter(u=>u.team===c.team&&u.kind==='infantry'),ids=new Set(selected.map(u=>u.id));
  const worker=r.units.find(u=>u.team===c.team&&u.kind==='worker');
  const passive=r.units.filter(u=>u.team!==c.team&&u.kind==='infantry');
  const pose=u=>[u.id,u.generation,u.x,u.z,u.hp,u.orderRevision,u.moveGoalCell,u.pathIndex,u.path,u.queuedWaypoints];
  let passiveBefore=null;
  const physical={selectedSubsteps:0,staticContactSteps:0,newPairContactSteps:0,
    illegalInheritedEscapeSteps:0,inheritedContactSteps:0,worstPairMargin:null,inactiveMilitaryPreserved:passive.length};
  const workerPhysical={selectedSubsteps:0,staticContactSteps:0,newPairContactSteps:0,illegalInheritedEscapeSteps:0,inheritedContactSteps:0,worstPairMargin:null};
  const controlMax={},repairHistory=[];
  const initial=r.checkpoint();
  await writeFile(`${output}/${c.name}-initial.json`,JSON.stringify(initial));
  const violations=[],handoffs=new Map(selected.map(u=>[u.id,{id:u.id,queuedLegStartTick:null,arrivalTick:null}]));
  const hash=createHash('sha256'),done=u=>!u.queuedWaypoints.length&&!u.movePlanningPending&&u.pathIndex===u.path.length
    &&Math.hypot(u.x-r.point(u.moveGoalCell).x,u.z-r.point(u.moveGoalCell).z)<.02;
  r.step=(...args)=>{
    passiveBefore??=structuredClone(passive.map(pose));
    const queued=selected.map(u=>u.queuedWaypoints.length);
    const result=step(...args);
    entitlement.afterTick(r);
    assert.deepEqual(passive.map(pose),passiveBefore,'inactive military pose and intent unchanged');
    trace.push(r.actorTrace);if(trace.length>20)trace.shift();
    for(const sample of r.crowdSteps.filter(s=>ids.has(s.id)))for(const [key,value] of Object.entries(sample))
      if(typeof value==='number'&&Number.isFinite(value))controlMax[key]=Math.max(controlMax[key]??0,value);
    assert.ok((controlMax.proposals??0)<=128,'existing proposal cap');
    for(let i=0;i<selected.length;i++){
      const u=selected[i],h=handoffs.get(u.id);
      if(queued[i]&&!u.queuedWaypoints.length)h.queuedLegStartTick=r.tick;
      if(h.arrivalTick===null&&done(u))h.arrivalTick=r.tick;
    }
    for(const s of r.landSteps){
      if(!ids.has(s.id)&&s.id!==worker.id)continue;
      const audit=ids.has(s.id)?physical:workerPhysical;
      audit.selectedSubsteps++;hash.update(JSON.stringify(s)+'\n');
      const radius=LAND_CLEARANCE_PROFILE.radiusByKind[s.kind];
      const stat=sweptStaticBodyContacts(s.from,s.to,radius,map.width,map.height,r.isWalkable).contacts.length>0;
      audit.staticContactSteps+=Number(stat);
      let inherited=false,newContact=false;
      for(const o of s.neighbours){
        const other=LAND_CLEARANCE_PROFILE.radiusByKind[o.kind];assert.ok(Number.isFinite(other));
        const margin=sweptBodyPairMargin(s,radius,o,other);
        audit.worstPairMargin=Math.min(audit.worstPairMargin??Infinity,margin);
        const startsContact=Math.hypot(s.from.x-o.x,s.from.z-o.z)<radius+other-1e-9;
        inherited||=startsContact;newContact||=!startsContact&&margin < -1e-9;
      }
      audit.inheritedContactSteps+=Number(inherited);audit.newPairContactSteps+=Number(newContact);
      const illegal=!canTraverseCrowdBodySegment(s.from,s.to,radius,s.neighbours.filter(o=>Math.hypot(s.from.x-o.x,s.from.z-o.z)<=Math.hypot(s.to.x-s.from.x,s.to.z-s.from.z)+radius+LAND_CLEARANCE_PROFILE.radiusByKind[o.kind]+1e-9),{allowEscape:true});
      audit.illegalInheritedEscapeSteps+=Number(illegal);
      if((stat||newContact||illegal)&&violations.length<20)violations.push({tick:r.tick,step:s,stat,newContact,illegal});
    }
    return result;
  };
  f.dispose=async()=>{
    try {
    const checkpoint=r.checkpoint();
    const summary={...c,tick:r.tick,arrived:selected.filter(done).length,queued:selected.filter(u=>u.queuedWaypoints.length).length,
      queuedLegs:selected.reduce((n,u)=>n+u.queuedWaypoints.length,0),pending:selected.filter(u=>u.movePlanningPending).length,
      distinctGoals:new Set(selected.map(u=>u.moveGoalCell)).size,physical:{...physical,traceSha256:hash.digest('hex')},workerPhysical,
      controlMax,entitlement:entitlement.summary(),repairSamples:r.planning.filter(p=>p.mode==='blocked-route-repair'),
      sourceRoot:"/workspace/crowd-entitlement-qualification-baseline",mapSha256:createHash('sha256').update(JSON.stringify(map)).digest('hex'),
      seed:map.terrainSeed,handoffs:[...handoffs.values()],unfinished:selected.filter(u=>!done(u)).map(u=>structuredClone(u)),violations};
    await writeFile(`${output}/${c.name}-summary.json`,JSON.stringify(summary,null,2)+'\n');
    await writeFile(`${output}/${c.name}-checkpoint.json`,JSON.stringify(checkpoint));
    await writeFile(`${output}/${c.name}-trace.json`,JSON.stringify(trace.flat()));
    } catch(error) { console.error('Evidence persistence failed:',error.message); }
    finally { await dispose(); }
  };
  return f;
}
