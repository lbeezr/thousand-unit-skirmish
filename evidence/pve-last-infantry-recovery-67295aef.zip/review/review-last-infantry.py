import datetime, gzip, hashlib, json, pathlib, subprocess, zipfile

root=pathlib.Path('/workspace/pve-scout-completion')
evidence=pathlib.Path('/workspace/pve-barracks-diagnosis-2026-10-05-evidence')
review=evidence/'review'
initial='ac33f8b27c4621c69c52c342ced0c446eb0040fe'
final='fb73e908858bff6f92fcec938d52b8786c42f952'
base='870a83d0808d5888bdfdee89e059194e4b8989ef'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==final
assert git('status','--porcelain')==b''
provenance=json.loads((root/'scripts/fixtures/pve-last-infantry/provenance.json').read_text())
archive_path=evidence/'input/cpu-qualification-172c53f3.zip'
assert sha(archive_path.read_bytes())==provenance['archiveSha256']
archive_rows=[]
with zipfile.ZipFile(archive_path) as archive:
    manifest=json.loads(archive.read('MANIFEST.json'))
    assert len(archive.namelist())==44 and len(manifest['entries'])==43
    for entry in manifest['entries']:
        value=archive.read(entry['path'])
        assert len(value)==entry['bytes'] and sha(value)==entry['sha256']
    for row in provenance['checkpoints']:
        prefix=f"tiny-failure-evidence/tiny-{row['mode']}-20260925-0/"
        raw=archive.read(prefix+'record.json');record=json.loads(raw)
        assert sha(raw)==row['recordSha256']
        import base64
        envelope=json.loads(archive.read(prefix+'envelope.json'))
        payload=gzip.decompress(base64.b64decode(envelope['data']))
        assert payload==raw and len(payload)==envelope['bytes'] and sha(payload)==envelope['sha256']
        compressed=(root/'scripts/fixtures/pve-last-infantry'/row['filename']).read_bytes()
        plain=gzip.decompress(compressed);loss=json.loads(plain)
        assert sha(compressed)==row['compressedSha256'] and len(compressed)==row['compressedBytes']
        assert sha(plain)==row['checkpointSha256'] and len(plain)==row['checkpointBytes']
        assert loss==record['final']==json.loads(archive.read(prefix+'final.json'))
        assert loss==json.loads((evidence/'input/extracted'/prefix/'final.json').read_text())
        assert record['source']=={'revision':provenance['source'],'dirty':False}
        assert loss['state']['tickNumber']==108000
        assert not any(u['team']==0 and u['hp']>0 for u in loss['state']['units'])
        assert len(record['lastDecisionViews'][1]['buildings']['visibleEnemies'])==0
        assaults=[x['tick'] for x in record['trace'] if x.get('team')==1 and x.get('command',{}).get('type')=='attackBuilding' and x['command']['buildingId']==2]
        assert len(assaults)==9 and assaults[-1]==78630
        army=[u for u in loss['state']['units'] if u['team']==1 and u['hp']>0 and u['kind'] not in ['worker','scout']]
        assert len(army)==11 and all(u['lastMoveTick']==108000 for u in army)
        archive_rows.append({'mode':row['mode'],'checkpointSHA256':sha(plain),'compressedSHA256':sha(compressed),
            'originalObjectEqualWithoutNormalization':True,'lastDecisionTick':record['lastDecisionViews'][1]['tick'],
            'priorBuildingAssaultTicks':assaults,'nativeArmyActorsMovingAtTerminal':11})
code_files=['src/pve-production.mjs','scripts/pve-last-infantry-case.mjs','scripts/pve-last-infantry.test.mjs',
            'scripts/pve-worker-recovery.test.mjs']
for path in code_files:assert git('show',f'{initial}:{path}')==git('show',f'{final}:{path}')
original_log=(review/'last-infantry-ac33f8-tests.log').read_text()
worker_log=(review/'worker-budget-ac33f8-tests.log').read_text()
assert 'tests 9' in original_log and 'pass 9' in original_log and 'fail 0' in original_log
assert 'tests 12' in worker_log and 'pass 12' in worker_log and 'fail 0' in worker_log
baseline=json.loads((evidence/'checkpoint-controls.json').read_text())
assert baseline['source']==provenance['source'] and baseline['dirty']==False
assert all(x['baseline']['trace']==[] and x['baseline']['purchase'] is None and x['baseline']['spawn'] is None for x in baseline['results'])
assert all(x['paid']['purchase']==108300 and x['paid']['spawn']==108661 for x in baseline['results'])
common={'findings':[],'verdict':'Approved: no blocking correctness, ownership/fog, priority, budget, native recovery, provenance or documentation finding.',
    'policyAssessment':{'explicitAffordableInfantryRequired':True,'noLivingOwnedUnitsRequired':True,
        'noPaidQueuesRequired':True,'livingWorkerProducerIncludingFoundationPreservesReserve':True,
        'existingWorkerRecoveryRemainsFirst':True,'oneLivingOrQueuedUnitRestoresOrdinaryReserve':True,
        'openingBackoffPopulationMilitaryRosterBlockedExitGuardsUnchanged':True,'noAuthorityMutationOrHiddenPolicyInput':True},
    'nativeScope':'Seat0 actual retained losses in authored@1 and skirmish@1; seat1 existing native orders continue. Pure guards cover both seats/three seeds.',
    'restoreComparison':'Complete authority equals expected; only documented Worker presentation row17 clears through existing shared assertion.',
    'fixtureProvenance':{'source':provenance['source'],'archiveSHA256':provenance['archiveSha256'],
        'archiveBytes':archive_path.stat().st_size,'members':44,'manifestEntriesVerified':43,'checkpointObjects':archive_rows},
    'baselineControlsReadNotIndependentlyRerun':{'source':baseline['source'],'normalTraceEmpty':True,
        'ordinaryForcedTrainPurchase':108300,'spawn':108661,'repeatAssertionsPresentInRetainedScript':True},
    'remainingLimits':['No full Tiny completion, search/route root cause, native seat1 loss equivalence, balance, deployment or rendered acceptance claimed.',
        'Fixed-tick short native recovery includes deliberate fresh-fixture cold queue restore; it is not uninterrupted normal two-policy competition.'],
    'fullNewGames':0,'sourceEditsByReviewer':0}
old={**common,'reviewedSource':initial,'base':'dbc83db33177b65817a9dcad3deae9453b018800',
    'reviewBoundary':'Recorded after integration; these original logs/raw outputs were executed at the previously observed clean ac33 head, before runtime integration.',
    'reviewedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'independentTests':[{'argv':['node','--test','scripts/pve-last-infantry.test.mjs'],'pass':9,'fail':0},
        {'argv':['node','--test','--test-name-pattern=Worker priority retains authoritative budgets and retry guards|restart an empty economy at the native Worker price','scripts/pve-worker-recovery.test.mjs'],'pass':12,'fail':0}],
    'codeSHA256':{p:sha(git('show',f'{initial}:{p}')) for p in code_files},
    'nonblockingPrecisionNoteResolvedInFinalDocs':'State existing Worker row17 transient exception for restart snapshot comparison.'}
with (review/'review-ac33f8.receipt.json').open('x') as f:json.dump(old,f,indent=2);f.write('\n')
final_log=(review/'fb73e908/last-infantry-tests.log').read_text()
assert 'tests 9' in final_log and 'pass 9' in final_log and 'fail 0' in final_log
results=[]
for mode in ['authored','skirmish']:
    data=json.loads((review/f'fb73e908/last-infantry-{mode}-0.json').read_text())
    result=data['result'];loss=data['input']['loss']
    assert result['stages']=={'purchase':108300,'restart':108300,'spawn':108661}
    assert result['final']['state']['teamFood'][0]==loss['state']['teamFood'][0]-50
    assert result['final']['state']['teamWood'][0]==loss['state']['teamWood'][0]
    assert sum(u['team']==0 and u['hp']>0 for u in result['final']['state']['units'])==1
    assert result['final']['state']['matchWinner']==-1
    results.append({'mode':mode,'stages':result['stages'],'paidFood':50,'remainingFood':result['final']['state']['teamFood'][0],
        'remainingWood':result['final']['state']['teamWood'][0],'livingOwnUnits':1,'ongoing':True,'exactRepeatAssertionPassed':True})
qa=(root/'docs/qa-pve-last-infantry-recovery-2026-10-05.md').read_text()
assert 'existing Worker transient row17 clearing contract' in qa and 'does not establish the cause or resolution' in qa
changed=git('diff','--name-only',base,final).decode().splitlines()
assert len(changed)==11 and all(p.startswith('docs/') or p.startswith('scripts/') or p=='src/pve-production.mjs' for p in changed)
assert (root/'scripts/pve-worker-recovery.test.mjs').read_text().count("import './pve-last-infantry.test.mjs';")==1
registered=json.loads((review/'ci-list-ac33f8.json').read_text())
assert any('scripts/pve-worker-recovery.test.mjs' in row['args'] and '--test' in row['args'] for row in registered)
new={**common,'reviewedSource':final,'base':base,'cleanWorktree':True,
    'reviewedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'ownedCodeUnchangedFromAc33':True,'changedFiles':changed,
    'independentFinalHeadTests':{'argv':['node','--test','scripts/pve-last-infantry.test.mjs'],'pass':9,'fail':0,'results':results},
    'priorIndependentWorkerBudgetGuards':{'source':initial,'pass':12,'fail':0,'codeByteIdentical':True},
    'codeSHA256':{p:sha((root/p).read_bytes()) for p in code_files},
    'newTestsRegisteredThroughExistingWorkerRecovery':True,'existingFullTinyAssertionsUnchanged':True,
    'exactFinalStatic':{'gitDiffCheck':'pass','syntax':'pass','docsCheck':'pass'}}
with (review/'fb73e908/review-final.receipt.json').open('x') as f:json.dump(new,f,indent=2);f.write('\n')
print(json.dumps(new,indent=2))
