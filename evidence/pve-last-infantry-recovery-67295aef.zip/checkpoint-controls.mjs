import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const root = process.argv[2];
const { createPveHeadlessFixture } = await import(pathToFileURL(`${root}/scripts/pve-headless-fixture.mjs`));
const { createDeterministicPolicy, toOpponentObservation } = await import(pathToFileURL(`${root}/src/pve-opponent.mjs`));
const source = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
const dirty = !!execFileSync('git', ['status', '--porcelain'], { cwd: root, encoding: 'utf8' }).trim();
const policyIdentity = { matchModeId: 'skirmish', matchModeVersion: 1 };
const results = [];
for (const mode of ['authored', 'skirmish']) {
  const record = JSON.parse(await readFile(new URL(`input/extracted/tiny-failure-evidence/tiny-${mode}-20260925-0/record.json`, import.meta.url)));
  async function run(forcedPurchase) {
    const fixture = await createPveHeadlessFixture(record.final.mapDefinition, record.nativeIdentity), r = fixture.replay;
    try {
      r.restore(record.final);
      assert.equal(r.checkpoint().state.tickNumber, 108000);
      const view = () => toOpponentObservation(r.observe(0), 0, record.final.mapDefinition);
      const initialView = view(), producer = initialView.buildings.friendly[0];
      assert.equal(initialView.units.friendly.filter(u => u.hp > 0).length, 0);
      assert.equal(producer.type, 'barracks');
      assert.equal(producer.productionOptions.find(o => o.kind === 'infantry').available, true);
      const hidden = structuredClone(r.observe(0)); hidden.food[1] = 100000; hidden.wood[1] = 100000;
      assert.deepEqual(toOpponentObservation(hidden, 0, record.final.mapDefinition), initialView);
      const policy = createDeterministicPolicy(record.seeds[0], policyIdentity), trace = [];
      let purchase = null, spawn = null;
      for (let step = 0; step <= 900; step++) {
        if (step % 30 === 0) {
          const observation = view();
          const commands = forcedPurchase && step === 300 ? [{ type: 'train', buildingId: producer.id }] : policy.next(observation);
          for (const command of commands) {
            const before = r.observe(0), notices = await r.order(0, command); r.drain();
            assert.ok(!notices.some(n => /REJECTED|FAILED|UNREACHABLE/.test(n.message || '')));
            trace.push({ tick: before.tick, command, notices });
            if (command.type === 'train') {
              assert.equal(before.food[0] - r.observe(0).food[0], 50);
              purchase ??= before.tick;
            }
          }
        }
        if (view().units.friendly.some(u => u.hp > 0 && u.kind === 'infantry')) spawn ??= r.observe(0).tick;
        if (step < 900) r.step();
      }
      return { forcedPurchase, purchase, spawn, trace, initialView, final: r.checkpoint() };
    } finally { await fixture.dispose(); }
  }
  const baseline = await run(false), paid = await run(true);
  assert.deepEqual(await run(false), baseline);
  assert.deepEqual(await run(true), paid);
  assert.equal(baseline.purchase, null); assert.equal(baseline.spawn, null); assert.deepEqual(baseline.trace, []);
  assert.equal(paid.purchase, 108300); assert.equal(paid.spawn, 108661);
  results.push({ mode, nativeIdentity: record.nativeIdentity, policyIdentity, baseline, paid });
  console.log(JSON.stringify({ mode, source, dirty, baseline: { purchase: baseline.purchase, spawn: baseline.spawn },
    paid: { purchase: paid.purchase, spawn: paid.spawn, food: paid.final.state.teamFood[0] },
    exactRepeat: true, hiddenBankProjectionEqual: true, winner: paid.final.state.matchWinner }));
}
await writeFile(new URL('checkpoint-controls.json', import.meta.url), JSON.stringify({ source, dirty, boundTicks: 900,
  fixture: 'unchanged terminal checkpoint, seat0 policy only; seat1 native orders continue; forced train is diagnostic only', results }, null, 2) + '\n');
