# Empty-army paid Infantry recovery evidence

PR428: https://github.com/lbeezr/thousand-unit-skirmish/pull/428

Reviewed final head fb73e908858bff6f92fcec938d52b8786c42f952;
merged67295aef1a744bde9000ce2c3d12e00b78a922e0. The merge tree equals
the reviewed tree. No deployment or rendered acceptance is established.

The immutable172c53f3qualification archive is retained under `input/`, with its
44members independently verified and extracted. Both original failure records
contain complete initial/final checkpoints, accepted ledger and last filtered
decision views. Their original3600second deadline is unchanged.

`packet-facts.json` extracts the relevant survivor, production availability and
prior assault facts. The Barracks alone is not assigned as a root cause.
`checkpoint-controls.mjs/.json/.log` strictly restore each original terminal
checkpoint at clean172c53f3, run a30second normal-policy baseline and a matched
ordinary forced-train control, and exactly repeat both full results. Baseline
spawns no unit; the diagnostic purchase pays50food and spawns at108661.
The forced command is not part of the policy change.

`source/` captures initial committed ac33f8b2changes; `source-final/` captures
the eleven own files at reviewed/merged source. Only production policy changes
runtime behavior. `module-comparison.json` and integration provenance retain
unchanged targeting, mode, economy definitions and policy byte comparisons.

`candidate/`, `integrated/` and `postmerge/` retain actual native input/results
at ac33f8b2,fb73e908 and67295aef respectively. The9focused regressions restore
both original checkpoint objects without authority edits. Normal policy pays
at108300, cold-restores the real paid queue at that tick in a fresh fixture and
spawns at108661. Both full repeated ledgers/final checkpoints exactly compare;
hidden enemy banks/undisclosed units leave observations equal. All commands are
accepted. Only seat0's policy runs; seat1's existing native orders continue.
Both short forks remain ongoing and start after the original failed deadline.
They do not establish native seat1 loss equivalence or whole-match completion.

`validation/` retains176initial focused passes,5production/tactical scenarios,
920initial syntax passes,122final-head focused passes,925final-head syntax
passes, import/type/docs/diff checks, and9postmerge passes. These scopes overlap;
their counts do not add to a full CPU qualification.
`review/` preserves independent original/final exact-head approval, fixtures
compared against the original archive without normalization,9final-head new
tests and12existing Worker budget guards on byte-identical code.

`outcome.json` records exact revisions, result fields, limits and remaining
owners. Full Tiny completion/search cause, full CPU qualification, deployment,
rendered acceptance and balance remain open. Medium remains human-only; no
map/admission/victory/native movement/economy edits belong to this PR.

Two exploratory logs are explicitly classified in outcome metadata. The first
control expected a12second spawn one tick early; the observed361tick queue was
then exactly repeated in both modes. Final committed evidence is separate.

Verify the sealed ZIP with `python verify.py /path/to/archive.zip`.
The manifest covers every archive member except itself, with size and SHA256.
