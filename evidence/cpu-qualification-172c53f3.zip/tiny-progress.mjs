import { readFileSync, existsSync, statSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const dir = '/workspace/cpu-qualification-172c53f3';
const frozen = JSON.parse(readFileSync(`${dir}/tiny-diagnostic-freeze.json`, 'utf8'));
const log = readFileSync(`${dir}/tiny-diagnostic.log`, 'utf8');
const lines = log.split('\n');
const git = (...args) => execFileSync('git', args, { cwd: frozen.source.checkout, encoding: 'utf8' }).trim();
console.log(JSON.stringify({ scope: frozen.scope, source: frozen.source.revision,
  currentSource: git('rev-parse', 'HEAD'), dirty: Boolean(git('status', '--porcelain')),
  elapsedSeconds: Math.round((Date.now() - Date.parse(frozen.startedAt)) / 1000),
  retainedLogBytes: statSync(`${dir}/tiny-diagnostic.log`).size,
  completePacketLines: lines.filter(line => line.includes('PVE_TINY_FAILURE ') && line.trim().endsWith('}')).length,
  outcomes: lines.filter(line => /^✔ |^✖ /.test(line)).slice(-4),
  successfulTerminalSummaries: lines.filter(line => line.startsWith('{"seeds":')).map(JSON.parse),
  finalSummary: lines.filter(line => /^ℹ (tests|pass |fail |duration_ms)/.test(line)).slice(-4),
  terminalPresent: existsSync(`${dir}/tiny-diagnostic-terminal.json`) }));
