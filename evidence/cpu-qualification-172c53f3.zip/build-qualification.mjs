import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const dir = '/workspace/cpu-qualification-172c53f3';
const json = name => JSON.parse(readFileSync(`${dir}/${name}.json`, 'utf8'));
const freeze = json('freeze'), report = json('report'), terminal = json('terminal');
const tinyTerminal = json('tiny-diagnostic-terminal'), index = json('tiny-evidence-index');
const registry = json('registry');
const text = readFileSync(`${dir}/tiny-diagnostic.log`, 'utf8');
const lines = text.split('\n');
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const sha = p => 'sha256:' + createHash('sha256').update(readFileSync(p)).digest('hex');
assert.equal(git('rev-parse', 'HEAD'), freeze.source.revision);
assert.equal(git('status', '--porcelain'), '');
for (const prior of freeze.priorAttempts) for (const [file, value] of Object.entries(prior.files)) {
  assert.equal(sha(`${prior.directory}/${file}`), value.sha256, 'prior evidence unchanged');
}
const cases = [...new Set(lines.filter(line => /^[✔✖] Tiny native/.test(line)))];
const successes = lines.filter(line => line.startsWith('{"seeds":')).map(JSON.parse);
assert.equal(cases.length, 4);
assert.equal(index.packets.length, 2);
assert.equal(successes.length, 2);
for (const line of ['ℹ tests 4', 'ℹ pass 2', 'ℹ fail 2', 'ℹ skipped 0']) assert.ok(lines.includes(line));
assert.equal(report.passedCount, 930);
assert.equal(report.unrunCount, 383);
assert.equal(report.selectedCount, 1314);
assert.equal(report.fullCpuSuitePassed, false);
const qualification = {
  schemaVersion: 1, source: freeze.source, includedFixes: freeze.includedFixes,
  fullAttempt: { classification: 'operator interrupted during unbounded native cleanup',
    command: freeze.command, exitCode: terminal.exitCode, finishedAt: terminal.finishedAt,
    status: report.status, selectedCount: report.selectedCount, passedCount: report.passedCount,
    interruptedCheckCount: report.checks.filter(check => check.status === 'failed').length,
    unrunCount: report.unrunCount, fullCpuSuitePassed: report.fullCpuSuitePassed,
    interruptedCheck: report.checks.at(-1), assertionFailureEstablished: false,
    nativePassSummaryIsNotProcessExit: true, operatorRecord: 'operator-interruption.json' },
  coverageFloors: freeze.scope.coverageFloors.map(check => ({ label: check.label, args: check.args,
    status: report.checks.find(outcome => outcome.label === check.label)?.status ?? 'unrun' })),
  dedicatedContracts: ['scripts/pve-skirmish-targets.test.mjs', 'scripts/pve-tiny-search.test.mjs',
    'scripts/pve-fog-restart.test.mjs', 'scripts/elimination-scenario.mjs'].map(file => ({ file,
      fullAttemptStatus: report.checks.find(check => check.label === registry.find(entry =>
        entry.args[0] !== '--check' && entry.args.includes(file))?.label)?.status ?? 'unrun' })),
  tinyDiagnostic: { scope: 'separate exact-source unchanged registered command; never stitched into full report',
    command: 'node --test scripts/pve-tiny-search.test.mjs', exitCode: tinyTerminal.exitCode,
    finishedAt: tinyTerminal.finishedAt, tests: 4, passed: 2, failed: 2, skipped: 0, cases, successes,
    failurePackets: index.packets, changedAssertionsBudgetsSeedsReplayReset: false,
    gameplayCause: 'not established; terminal and filtered views are now retained for owner diagnosis' },
  ownership: {
    fullCleanup: { owner: 'fixture stream 01a1085f',
      coordination: 'https://github.com/lbeezr/thousand-unit-skirmish/pull/419#issuecomment-5987167121',
      nextAction: 'Resolve bounded client-close/server teardown behavior; new immutable full qualification is needed after owned fixes.' },
    tiny: { owner: 'AI 01a10297', coordination: 'https://github.com/lbeezr/thousand-unit-skirmish/pull/420',
      nextAction: 'Consume retained exact-source terminal/trace/filtered-view packets before diagnosing or changing gameplay.' },
    mediumSchema: { owner: 'fixture stream 01a1085f',
      classification: 'Parent-confirmed separate schema30 migration fixture gap; unrun in this full attempt.',
      coordination: 'https://github.com/lbeezr/thousand-unit-skirmish/pull/420#issuecomment-5987105017' } },
  constraints: { sourceEdits: 0, fullAttemptRetries: 0, changedRegistrationsFloorsBudgets: 0,
    manualHostedDispatch: false, hostedAuthenticationRetry: false, newDependencies: false,
    renderedOrDeploymentAcceptanceClaim: false },
  priorEvidenceUnchanged: true, independentReview: { status: 'pending final evidence review' },
  evidenceDirectory: dir,
};
writeFileSync(`${dir}/qualification.json`, JSON.stringify(qualification, null, 2) + '\n');
console.log(JSON.stringify({ full: qualification.fullAttempt,
  floors: qualification.coverageFloors.map(check => ({ label: check.label, status: check.status })),
  tiny: { tests: 4, passed: 2, failed: 2, packets: index.packets.length }, priorEvidenceUnchanged: true }));
