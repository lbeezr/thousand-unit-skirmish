import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { decodeTinyFailureEvidence, TINY_FAILURE_PREFIX } from '/workspace/thousand-unit-skirmish-elimination-fixture/scripts/pve-tiny-failure-evidence.mjs';

const dir = '/workspace/cpu-qualification-172c53f3';
const frozen = JSON.parse(readFileSync(`${dir}/freeze.json`, 'utf8'));
const logName = process.argv[2] ?? 'suite.log';
assert.ok(['suite.log', 'tiny-diagnostic.log'].includes(logName));
const log = readFileSync(`${dir}/${logName}`, 'utf8');
const label = '== Tiny authored and native Skirmish: fog, paid production, exact replay and reset ==';
const start = log.indexOf(label);
const end = start < 0 ? -1 : log.indexOf('\n== ', start + label.length);
const section = logName === 'tiny-diagnostic.log' ? log : start < 0 ? '' : log.slice(start, end < 0 ? undefined : end);
const packets = [];
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
for (const line of section.split('\n')) {
  const prefix = line.indexOf(TINY_FAILURE_PREFIX);
  if (prefix < 0) continue;
  const envelope = JSON.parse(line.slice(prefix + TINY_FAILURE_PREFIX.length));
  const record = decodeTinyFailureEvidence(envelope);
  assert.equal(record.source.revision, frozen.source.revision);
  assert.equal(record.source.dirty, false);
  assert.equal(record.final.state.matchWinner, -1);
  assert.equal(record.policyIdentity.matchModeId, 'skirmish');
  assert.equal(record.policyIdentity.matchModeVersion, 1);
  assert.ok(Array.isArray(record.trace));
  assert.equal(record.lastDecisionViews.length, 2);
  const name = `tiny-${record.nativeIdentity.matchModeId}-${record.seeds.join('-')}`;
  assert.ok(!packets.some(packet => packet.name === name), 'one actual failure packet per native case');
  const folder = `${dir}/tiny-failure-evidence/${name}`;
  mkdirSync(folder, { recursive: true });
  const bytes = gunzipSync(Buffer.from(envelope.data, 'base64'));
  writeFileSync(`${folder}/envelope.json`, JSON.stringify(envelope) + '\n');
  writeFileSync(`${folder}/record.json`, bytes);
  writeFileSync(`${folder}/record.json.gz`, Buffer.from(envelope.data, 'base64'));
  for (const key of ['initial', 'final', 'trace', 'metrics', 'lastDecisionViews']) {
    writeFileSync(`${folder}/${key}.json`, JSON.stringify(record[key]) + '\n');
  }
  const summary = { name, source: record.source, nativeIdentity: record.nativeIdentity,
    policyIdentity: record.policyIdentity, seeds: record.seeds, winner: record.final.state.matchWinner,
    terminalStateClock: Object.fromEntries(Object.entries(record.final.state).filter(([key]) => /tick|time|winner/i.test(key))),
    lastDecisionTicks: record.lastDecisionViews.map(view => view?.tick),
    traceEntries: record.trace.length, finalTraceTick: record.trace.at(-1)?.tick,
    rawDecodedBytes: bytes.length, rawDecodedSha256: sha(bytes),
    compressedBytes: Buffer.from(envelope.data, 'base64').length,
    evidenceDirectory: folder, envelopeVerified: true, diagnosis: 'not established' };
  writeFileSync(`${folder}/summary.json`, JSON.stringify(summary, null, 2) + '\n');
  packets.push(summary);
}
const result = { source: frozen.source.revision, evidenceLog: `${dir}/${logName}`,
  scope: logName === 'suite.log' ? 'default full attempt' : 'separate unchanged Tiny diagnostic',
  tinyBatchStarted: logName === 'tiny-diagnostic.log' || start >= 0,
  retainedActualFailurePackets: packets.length, packets, provenance: 'Extracted from complete retained stdout/stderr of the named exact-source execution; no extra simulations or production changes during extraction.' };
writeFileSync(`${dir}/tiny-evidence-index.json`, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
