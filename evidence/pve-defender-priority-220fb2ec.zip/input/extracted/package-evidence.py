#!/usr/bin/env python3
"""Seal already-closed CPU artifacts; this script executes no game code."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path('/workspace/cpu-qualification-67295aef')
excluded = {'MANIFEST.json', 'archive-receipt.json', 'delivery-receipt.json', 'qualification-final.json'}
members = sorted(path for path in root.rglob('*') if path.is_file()
                 and path.name not in excluded and path.suffix != '.zip')
entries = [{'path': str(path.relative_to(root)), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in members]
qualification = json.loads((root / 'qualification.json').read_text())
assert qualification['independentReview']['status'] == 'passed', 'Review must finish before sealing.'
manifest = {'schemaVersion': 1, 'source': qualification['source']['revision'],
            'scope': 'one normal unchanged immutable full CPU attempt',
            'entries': entries}
manifest_file = root / 'MANIFEST.json'
manifest_file.write_text(json.dumps(manifest, indent=2) + '\n')
archive_file = root / 'cpu-qualification-67295aef.zip'
with zipfile.ZipFile(archive_file, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    archive.write(manifest_file, 'MANIFEST.json')
    for path in members:
        archive.write(path, str(path.relative_to(root)))
receipt = {'schemaVersion': 1, 'source': manifest['source'], 'archive': str(archive_file),
           'bytes': archive_file.stat().st_size, 'members': len(entries) + 1,
           'sha256': hashlib.sha256(archive_file.read_bytes()).hexdigest(),
           'manifestSha256': hashlib.sha256(manifest_file.read_bytes()).hexdigest(),
           'exactConsoleOutputPreserved': True, 'verifiedActualTinyPackets': qualification['failurePackets']['retainedActualFailurePackets'],
           'fullCpuSuitePassed': qualification['result']['fullCpuSuitePassed']}
(root / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
