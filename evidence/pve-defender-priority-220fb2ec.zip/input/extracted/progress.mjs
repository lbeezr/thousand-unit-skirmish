import { execFileSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
const root = '/workspace/cpu-qualification-67295aef';
const frozen = JSON.parse(readFileSync(`${root}/freeze.json`, 'utf8'));
const registry = JSON.parse(readFileSync(`${root}/registry.json`, 'utf8'));
const headers = new Set(registry.map(check => `== ${check.label} ==`));
const lines = readFileSync(`${root}/suite.log`, 'utf8').split('\n');
const started = lines.filter(line => headers.has(line));
const summary = {
  source: frozen.source.revision,
  currentSource: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: frozen.source.checkout, encoding: 'utf8' }).trim(),
  dirty: Boolean(execFileSync('git', ['status', '--porcelain'], { cwd: frozen.source.checkout, encoding: 'utf8' }).trim()),
  elapsedSeconds: Math.round((Date.now() - Date.parse(frozen.frozenAt)) / 1000),
  startedRegisteredChecks: started.length,
  lastCheck: started.at(-1),
  latestBatchSummary: lines.filter(line => /^ℹ (tests|pass |fail |duration_ms)/.test(line)).slice(-4),
  failedTestTitles: lines.filter(line => /^✖ /.test(line)).slice(-4),
  recentScenarioStages: lines.slice(lines.findLastIndex(line => headers.has(line))).filter(line => line.startsWith('{\"stage\":')).slice(-2),
  recentNativeModes: lines.slice(lines.findLastIndex(line => headers.has(line))).filter(line => line.startsWith('{\"mode\":')).slice(-2).map(line => { const x = JSON.parse(line); return {mode:x.mode,continued:x.continued,coldRecovered:x.coldRecovered}; }),
  latestCurrentTestOutcomes: lines.slice(lines.findLastIndex(line => headers.has(line))).filter(line => /^✔ |^✖ /.test(line)).slice(-2),
  terminalPresent: existsSync(`${root}/terminal.json`),
};
if (existsSync(`${root}/report.json`)) {
  const report = JSON.parse(readFileSync(`${root}/report.json`, 'utf8'));
  summary.result = { source: report.source, lane: report.lane, shard: report.shard,
    status: report.status, selectedCount: report.selectedCount,
    passedCount: report.passedCount, unrunCount: report.unrunCount,
    fullCpuSuitePassed: report.fullCpuSuitePassed,
    lastChecks: report.checks.slice(-3) };
}
console.log(JSON.stringify(summary));
