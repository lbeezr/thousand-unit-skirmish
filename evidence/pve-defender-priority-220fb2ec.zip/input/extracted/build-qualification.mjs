import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = '/workspace/cpu-qualification-67295aef';
const json = name => JSON.parse(readFileSync(`${root}/${name}.json`, 'utf8'));
const freeze = json('freeze'), report = json('report'), terminal = json('terminal');
const registry = json('registry');
const log = readFileSync(`${root}/suite.log`, 'utf8');
const lines = log.split('\n');
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const hash = path => 'sha256:' + createHash('sha256').update(readFileSync(path)).digest('hex');
assert.equal(git('rev-parse', 'HEAD'), freeze.source.revision);
assert.equal(git('status', '--porcelain'), '');
assert.deepEqual(report.source, { revision: freeze.source.revision, dirty: false });
assert.equal(report.lane, 'full');
assert.deepEqual(report.shard, { index: 1, count: 1 });
assert.equal(report.selectedCount, registry.length);
assert.deepEqual(JSON.parse(lines.find(line => line.startsWith('CI_RESULT ')).slice(10)), report);
assert.deepEqual(report.checks.map(check => check.label), registry.slice(0, report.checks.length).map(check => check.label));
const failedCount = report.checks.filter(check => check.status === 'failed').length;
assert.equal(report.passedCount + failedCount + report.unrunCount, registry.length);
assert.equal(report.fullCpuSuitePassed, report.status === 'passed' && report.passedCount === registry.length);
assert.equal(terminal.source.revision, freeze.source.revision);
assert.equal(terminal.source.dirty, false);
for (const previous of freeze.priorAttempts) for (const [name, record] of Object.entries(previous.files)) {
  assert.equal(hash(`${previous.directory}/${name}`), record.sha256, 'prior artifact must remain unchanged');
}
const outcome = file => {
  const entry = registry.find(check => check.args[0] !== '--check' && check.args.includes(file));
  const result = report.checks.find(check => check.label === entry?.label);
  const header = entry ? `== ${entry.label} ==` : null;
  const start = header ? log.indexOf(header) : -1;
  const end = start >= 0 ? log.indexOf('\n== ', start + header.length) : -1;
  const section = start < 0 ? [] : log.slice(start, end < 0 ? undefined : end).split('\n').filter(line => !line.startsWith('CI_RESULT '));
  return { file, label: entry?.label, status: result?.status ?? 'unrun', exitCode: result?.exitCode ?? null,
    batchSummaries: section.filter(line => /^ℹ (tests|pass |fail |skipped |duration_ms)/.test(line)),
    caseOutcomes: [...new Set(section.filter(line => /^[✔✖] /.test(line)))],
    terminalSummaries: section.filter(line => line.startsWith('{"seeds":')).map(JSON.parse) };
};
const qualification = {
  schemaVersion: 1, source: freeze.source, includedFixes: freeze.includedFixes,
  command: freeze.command, classification: 'normal unchanged unsharded full CPU attempt',
  result: { status: report.status, exitCode: terminal.exitCode, finishedAt: terminal.finishedAt,
    selectedCount: report.selectedCount, passedCount: report.passedCount, failedCount,
    unrunCount: report.unrunCount, fullCpuSuitePassed: report.fullCpuSuitePassed,
    failedChecks: report.checks.filter(check => check.status === 'failed') },
  coverageFloors: freeze.scope.coverageFloors.map(check => ({ ...check,
    status: report.checks.find(outcome => outcome.label === check.label)?.status ?? 'unrun' })),
  keyContracts: ['scripts/completion-event-scenario.mjs', 'scripts/completion-event-cleanup.test.mjs',
    'scripts/pathing-replay.test.mjs', 'scripts/pve-worker-recovery.test.mjs', 'scripts/pve-skirmish-targets.test.mjs',
    'scripts/pve-tiny-search.test.mjs', 'scripts/pve-fog-restart.test.mjs',
    'scripts/elimination-scenario.mjs'].map(outcome),
  failurePackets: existsSync(`${root}/tiny-evidence-index.json`) ? json('tiny-evidence-index') : null,
  priorNarrowCheckpointEvidence: { reportedByParent: 'PR428 retained-checkpoint paid Infantry spawn in 22.03 seconds with cold restore and exact replay',
    scope: 'existing narrower checkpoint success; never contributes to this full result' },
  priorEvidenceUnchanged: true,
  constraints: { sourceChangesDuringRun: 0, retriesOfThisFullAttempt: 0, manualHostedDispatch: false,
    authenticationRetry: false, changedRegistryFloorsAssertionsBudgets: false,
    newDependencies: false, browserRenderedOrDeploymentAcceptanceClaim: false },
  independentReview: { status: 'pending' },
};
writeFileSync(`${root}/qualification.json`, JSON.stringify(qualification, null, 2) + '\n');
console.log(JSON.stringify({ source: qualification.source, result: qualification.result,
  floors: qualification.coverageFloors.map(check => ({ label: check.label, status: check.status })),
  keyContracts: qualification.keyContracts.map(check => ({ file: check.file, status: check.status, batchSummaries: check.batchSummaries })),
  failurePackets: qualification.failurePackets?.retainedActualFailurePackets ?? 0, priorEvidenceUnchanged: true }));
