# Bounded disclosed defender priority evidence — 5 October 2026

Owner: Opponent AI01a10297. PR437. Original failure source67295aef;
production correction final head068822a90e7ae6cc285d1c5e0c2ad8600a4627ad.
This package establishes a bounded target-priority weakness and real native
assault improvement. It does not establish full Tiny completion, rendered play,
balance or deployment. No local whole-match retry or competing qualification plan was launched.

`input/cpu-qualification-67295aef.zip` is the CI owner's immutable normal full
attempt:1105passed/1failed/217unrun, original seeds ongoing3600s in both modes;
reversed seeds complete/exact-repeat2711s. All40original members and both actual
failure records were independently verified using `input/verify-evidence.py`.
The extracted records, map/native identities, final whole checkpoints, accepted
traces, metrics and actual filtered views are retained under `input/extracted/`.
Original archive SHA256:
6c9c9030e1b19d4dd7ded618e18a7e81251fc0335af6a63d0b3b8ce8d1ee1b4b.

Canonical mechanism evidence is `priority-*.json`, `priority-summary.json` and
`priority-probe.log`. `priority-probe.mjs` imports exact git-archive source in
`exact-source-67295aef/`, with only a candidate policy overlay. Both seats use
normal policy/public observations every30ticks. Both actual native modes run
60seconds from the failed deadline, baseline/candidate and exact repeats. Death
health sampling occurs only at native3tick publication boundaries. Baseline
loses all4frontline attackers while disclosed Infantry95 remains100HP; the
candidate observes its death by108078, retains all4with304combinedHP, resumes
Town Center attacks108090 and inflicts500.4HP instead of183.6HP. Accepted ledgers,
physical samples and full native checkpoint hashes repeat within every branch.
Both forks remain ongoing. No forced orders, resource/authority edits or weaker
full completion assertion.

`superseded-per-tick-probe/` preserves the earlier experiment and explicit
methodology warning. Off-phase checkpoint capture calls ensureVisionMasks;
those receipts are NOT canonical normal-cadence evidence. `cadence-comparison.json`
compares the corrected and superseded work without stripping authority. Old/new
physical samples and accepted ledgers agree, but baseline final hashes differ;
there is NO general authority/cadence invariance claim. Only corrected controls
are used for current findings.

`candidate-main/` contains preliminary14new tests and169focused passes from the
candidate over b02ea4fa, plus653docs/4933links. `head-c485aaee/` retains the clean
initial head166focused passes,14native fixture receipts and944registered
syntax/import/type/docs passes. Those earlier native receipts used superseded
per-tick death sampling. The six-line production policy itself is unchanged by
review correction. `corrected-native-cadence/` verifies corrected14tests; final
clean-head `head-068822a9/` repeats14/14 and changed helper syntax/docs checks.
All four current real-seat1 native variants (two modes × warm/fresh combat
restore at108030) observe death in (108075,108078], keep all4original attackers
and repeat every accepted command/notice and the entire terminal authority.
Warm Town Center damage500.4HP; cold498.6HP. Direct tests cover both seats/3seeds,
all6military public range boundaries, hidden-input equivalence, generation and
combat protection. No seat0-native equivalent is inferred.

Exact-source excerpts are in `source-67295aef/`, `source-c485aaee/` and
`source-068822a9/`. Independent review approves068822a9 with no blocking findings;
its exact argv/hashes/receipt and two old-selector negative controls are under
`review/native-boundary/`. All40input members and both whole fixture objects were
independently verified without normalization. Earlier reviewer per-tick controls
under `review/` are historical. The methodology finding is closed.

PR437 merged220fb2ecbd46cd3539a2c6741cf91200c696082b over
c1d1e76d5b7f4a6d9b618473078d0f22ce60d0f5. Every11owned file blob equals reviewed
068822a9; `postmerge-220fb2ec/merge.json` records parents, tree and equality.
The clean exact merged-source regression passes14/14 with identical reported
combat improvement; documentation links pass654Markdown/4951localLinks.
No full CPU-suite, independent deployment or rendered acceptance is claimed.
The regression fixtures preserve every original decoded authority field with
compressed/decoded/record digests. Changes are limited to one AI selector,
scenario/provenance and owning QA/plans. Server, movement, economy, map, mode and
victory contracts remain unchanged by this PR. Current Frontier remains2seats;
Medium remains human-only. CI01a10378 owns normal full qualification after this
substantive correction; AI/shared staging and capture retain rendered acceptance.
