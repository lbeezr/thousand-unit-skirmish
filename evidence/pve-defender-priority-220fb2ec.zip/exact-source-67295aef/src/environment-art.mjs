import { terrainHeightField, groundHeight } from './terrain-height.mjs';
import { REGIONS } from './regions.mjs';
import { TERRAIN_MATERIALS, forestGroundForBase } from './terrain-materials.mjs';
import { CAMERA_VIEW_DIRECTION } from './camera-controls.mjs';
import * as THREE from 'three';
import { fetchVerifiedRuntimeImage } from './presentation/assets/interactive-runtime-image.mjs';
import { RESOURCE_VISUAL_STAGES, resourceVisualStage } from './resource-visual-state.mjs';
import { createGroundMistStudy, groundMistEnabled } from './terrain-atmosphere.mjs';
import { applyTerrainTextureSampling } from './terrain-texture-sampling.mjs';
import { createTerrainCliffFaces } from './terrain-cliff-faces.mjs';
import { createPalisadeConstructionGroundMesh } from './palisade-construction-ground.mjs';
import { groundTextureName, loadPaintedMaterialAtlas } from './painted-material-atlas-runtime.mjs';
import { loadOakDepletionAtlas, oakDepletionStage, applyOakDepletionSampling } from './oak-depletion-atlas-runtime.mjs';
import { buildTerrainBlendMasks, buildForestGroundMask } from './terrain-blend.mjs';
import { buildWaterSurfaceGeometry, WATER_LEVEL } from './water-surface-geometry.mjs';
import { createWaterSurfaceStudy, waterSurfaceOptions } from './water-surface-study.mjs';
import { createShoreBankShade } from './shore-bank-shade.mjs';
import { forestHabitatDepth, forestCanopyFactor, forestMarginCanopyFactor } from './forest-habitat.mjs';
import { forestAgeFactors } from './forest-age-composition.mjs';
import { underboughForestSpecies } from './forest-composition.mjs';
import { shorePlantPositions } from './shore-vegetation.mjs';
import { meadowPlantGroups, drylandPlantGroups, snowPlantGroups, ridgePlantGroups, lunarPlantGroups, marshPlantGroups, junglePlantGroups } from './meadow-vegetation.mjs';
import { gardenPlantGroups } from './garden-vegetation.mjs';
import { assertPlantDimensions, PLANT_ASSETS } from './environment-plant-assets.mjs';
import { PODVINE_LOW_PACK as PODVINE_VIEW_PACK } from './podvine-low-pack.mjs';
import { VEILCAP_WORKED_PACK as VEILCAP_VIEW_PACK } from './veilcap-worked-pack.mjs';
import { SUNBLOOM_LOW_PACK as SUNBLOOM_VIEW_PACK } from './sunbloom-low-pack.mjs';

const meshyResourcesEnabled = new URLSearchParams(globalThis.location?.search ?? '').get('meshyResources') !== '0';

const ASSET_ROOT = './assets/environment/frontier-v1/';
const INTERACTIVE_ASSET_ROOT = './assets/environment/frontier-interactive-v1/';
const GROUND_RENDER_ORDER = -20;
export { TERRAIN_MATERIALS } from './terrain-materials.mjs';
const spriteNames = [
  'underbough-muted-copperleaf-v2', 'underbough-muted-copperleaf-v2-worked', 'underbough-muted-copperleaf-v2-low', 'underbough-muted-copperleaf-v2-depleted',
  'underbough-leafy-hornbeam-v2', 'underbough-leafy-hornbeam-v2-worked', 'underbough-leafy-hornbeam-v2-low', 'underbough-leafy-hornbeam-v2-depleted',
  'underbough-young-hornbeam', 'underbough-young-hornbeam-worked', 'underbough-young-hornbeam-low', 'underbough-young-hornbeam-depleted',
  'underbough-low-hazel',
  'underbough-thornberry', 'underbough-thornberry-worked', 'underbough-thornberry-low', 'underbough-thornberry-depleted',
  'ru-lora-fringe-broadleaf', 'sombral-mere-mirelily', 'bellweather-meadow-herbs', 'bellweather-meadow-clover', 'bellweather-wild-barley', 'vesperra-shade-fern', 'vesperra-shade-fern-02', 'vesperra-veilcap', 'vesperra-spiral-podvine', 'siltmouths-silver-reed', 'siltmouths-marsh-tuber', 'pale-meridian-violet-lichen', 'pale-meridian-silver-moss', 'pale-meridian-frostberry', 'sombral-mere-lunewort', 'sombral-mere-noctilune', 'underbough-rootward-fungus', 'underbough-rootward-fungus-02', 'veyrholds-ridgegrass', 'veyrholds-suncrest', 'ellionar-sunbloom', 'ellionar-garden-vine', 'sereward-succulent', 'sereward-succulent-02',
  'pine', 'silver-birch', 'field-maple', 'hazel-thicket',
  'bellweather-field-maple', 'bellweather-hedgerow',
  'bellweather-hedgerow-worked', 'bellweather-hedgerow-low', 'bellweather-hedgerow-depleted',
  'bellweather-field-maple-worked', 'bellweather-field-maple-low', 'bellweather-field-maple-depleted',
  'veyrholds-highpine-worked', 'veyrholds-highpine-low', 'veyrholds-highpine-depleted',
  'veyrholds-alpine-moss', 'veyrholds-highpine', 'veyrholds-ironlichen-outcrop', 'ru-lora-fiendwood', 'ru-lora-stone-fern', 'ru-lora-broken-trunk', 'ru-lora-god-bone',
  'underbough-copperleaf', 'underbough-bramble',
  'underbough-old-plum', 'underbough-old-plum-worked', 'underbough-old-plum-low', 'underbough-old-plum-depleted',
  'underbough-moss-hornbeam', 'underbough-moss-hornbeam-worked', 'underbough-moss-hornbeam-low', 'underbough-moss-hornbeam-depleted',
  'underbough-root-oak', 'underbough-root-oak-worked', 'underbough-root-oak-low', 'underbough-root-oak-depleted',
  'underbough-bramble-worked', 'underbough-bramble-low', 'underbough-bramble-depleted',
  'underbough-copperleaf-worked', 'underbough-copperleaf-low', 'underbough-copperleaf-depleted',
  'sereward-palm', 'sereward-acacia', 'sereward-scrub',
  'sereward-palm-worked', 'sereward-palm-low', 'sereward-palm-depleted',
  'sereward-scrub-worked', 'sereward-scrub-low', 'sereward-scrub-depleted',
  'sereward-acacia-worked', 'sereward-acacia-low', 'sereward-acacia-depleted',
  'pale-meridian-conifer', 'pale-meridian-conifer-worked', 'pale-meridian-conifer-low', 'pale-meridian-conifer-depleted',
  'sombral-mere-merebloom', 'sombral-mere-merebloom-worked', 'sombral-mere-merebloom-low', 'sombral-mere-merebloom-depleted',
  'ru-lora-fringe-canopy', 'ru-lora-fringe-canopy-worked', 'ru-lora-fringe-canopy-low', 'ru-lora-fringe-canopy-depleted',
  'vesperra-mistbark', 'vesperra-mistbark-worked', 'vesperra-mistbark-low', 'vesperra-mistbark-depleted',
  'siltmouths-tidal-tree', 'siltmouths-tidal-tree-worked', 'siltmouths-tidal-tree-low', 'siltmouths-tidal-tree-depleted',
  'ellionar-cultivated-palm', 'ellionar-garden-hedge',
  'ellionar-cultivated-palm-worked', 'ellionar-cultivated-palm-low', 'ellionar-cultivated-palm-depleted',
  'ellionar-garden-hedge-worked', 'ellionar-garden-hedge-low', 'ellionar-garden-hedge-depleted',
  'rock-outcrop', 'basalt-ridge', 'cliff', 'seamstone',
  'rock-boulder-cluster', 'basalt-ridge-cap', 'cliff-end-cap',
];
const textureLoader = new THREE.TextureLoader();
const spriteMaterials = new Map();
const constructionTextures = new Map();
const constructionMaterials = new Map();
const constructionInstances = new Map();
const forestAtlasPacks = new Map(await Promise.all(['bellweather', 'sereward', 'pale-meridian', 'siltmouths', 'vesperra', 'sombral-mere', 'underbough', 'underbough-bramble', 'underbough-root-oak', 'underbough-moss-hornbeam', 'underbough-young-hornbeam', 'underbough-leafy-hornbeam-v2', 'underbough-muted-copperleaf-v2', 'underbough-old-plum', 'veyrholds', 'ellionar', 'ellionar-hedge', 'sereward-acacia', 'sereward-scrub', 'bellweather-hedgerow', 'ru-lora-fringe'].map(async (region) => {
  try {
    const response = await fetch(`${ASSET_ROOT}${region}-lifecycle-atlas.json`);
    if (!response.ok) throw new Error(`atlas metadata HTTP ${response.status}`);
    const pack = await response.json();
    const asset = pack.assets[0], page = pack.pages[0];
    const file = pack.files.find((entry) => entry.id === page.runtimeFileId);
    if (file?.path !== `${region}-lifecycle-atlas.webp` || !page.sampling.generateMipmaps
      || page.sampling.maxMipLevel !== 6 || page.gutterPx !== 64
      || page.sampling.uvInsetPx !== 0.5 || !RESOURCE_VISUAL_STAGES.every((stage) => asset.frames.some((frame) => frame.id === stage))) {
      throw new Error('unsupported forest atlas contract');
    }
    return [asset.id, { asset, page, file }];
  } catch (error) {
    console.warn(`Forest atlas ${region} unavailable; using individual state textures`, error.message);
    return [region, null];
  }
})));
const forestAtlasTextures = new Map();

function createForestAtlasInstances(name, width, height, positions) {
  const pack = forestAtlasPacks.get(name);
  if (!pack || !positions.length) return null;
  let texture = forestAtlasTextures.get(name);
  if (!texture) {
    texture = loadSprite(`${ASSET_ROOT}${pack.file.path}`);
    texture.generateMipmaps = true;
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    forestAtlasTextures.set(name, texture);
  }
  const geometry = spriteGeometry(width, height, name);
  const rects = new THREE.InstancedBufferAttribute(new Float32Array(positions.length * 4), 4);
  geometry.setAttribute('environmentAtlasRect', rects);
  const material = new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide,
    transparent: true, alphaTest: 0.08, depthWrite: true, toneMapped: false });
  material.onBeforeCompile = (shader) => {
    shader.vertexShader = 'attribute vec4 environmentAtlasRect;\n' + shader.vertexShader;
    shader.vertexShader = shader.vertexShader.replace('#include <uv_vertex>',
      '#include <uv_vertex>\nvMapUv = environmentAtlasRect.xy + vMapUv * environmentAtlasRect.zw;');
    shader.uniforms.environmentAtlasSize = { value: new THREE.Vector2(
      pack.page.dimensionsPx.width, pack.page.dimensionsPx.height) };
    shader.fragmentShader = 'uniform vec2 environmentAtlasSize;\n' + shader.fragmentShader;
    const mapChunk = THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )',
      `textureLod(map, vMapUv, min(6.0, max(0.0, 0.5 * log2(max(
        dot(dFdx(vMapUv) * environmentAtlasSize, dFdx(vMapUv) * environmentAtlasSize),
        dot(dFdy(vMapUv) * environmentAtlasSize, dFdy(vMapUv) * environmentAtlasSize))))))`);
    shader.fragmentShader = shader.fragmentShader.replace('#include <map_fragment>', mapChunk);
  };
  material.customProgramCacheKey = () => 'vaelora-forest-atlas-v1';
  const mesh = new THREE.InstancedMesh(geometry, material, positions.length);
  mesh.frustumCulled = false;
  const frameRects = Object.fromEntries(pack.asset.frames.map((frame) => {
    const r = frame.fallbackRectPx.rectPx, p = pack.page.dimensionsPx;
    return [frame.id, [(r.x + 0.5) / p.width, 1 - (r.y + r.height - 0.5) / p.height,
      (r.width - 1) / p.width, (r.height - 1) / p.height]];
  }));
  mesh.userData.forestAtlas = { rects, frameRects };
  for (let index = 0; index < positions.length; index++) {
    setForestSpriteStock({ mesh, index, ...positions[index], atlas: mesh.userData.forestAtlas });
  }
  return mesh;
}

function loadSprite(url) {
  const texture = textureLoader.load(url);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  return texture;
}

// Decorative families load when a map uses them; resource-state fallbacks stay eager.
const sprites = {};
const directionalResource = name => /^(oak|pine|berries)-view-(0[0-7])$/.exec(name);
sprites.oak = loadSprite(`${ASSET_ROOT}oak.webp`);
sprites.berries = loadSprite(`${ASSET_ROOT}berries.webp`);
if (meshyResourcesEnabled) {
  for (const family of ['oak', 'pine', 'berries']) {
    sprites[family] = loadSprite(`./assets/environment/frontier-meshy-sprites-v1/${family}/runtime/${family}-01.webp`);
  }
}
for (const family of ['oak', 'berries']) {
  for (const stage of RESOURCE_VISUAL_STAGES) sprites[`${family}-${stage}`] = sprites[family];
}

const REQUIRED_RESOURCE_STATE_FILES = Object.freeze([
  ...['oak', 'berries'].flatMap((family) => RESOURCE_VISUAL_STAGES.map((stage) => `${family}-${stage}.webp`)),
  'construction-earthwork.webp', 'construction-foundation.webp',
]);
export let RESOURCE_STATE_ASSETS_AVAILABLE = false;
export let RESOURCE_STATE_ASSET_STATUS = {
  ready: false,
  state: 'loading',
  packId: 'environment.frontier-interactive',
  packVersion: null,
  loadedFiles: [],
  reason: 'manifest loading',
};

function textureMaterials(registry, key) {
  let materials = registry.get(key);
  if (!materials) {
    materials = new Set();
    registry.set(key, materials);
  }
  return materials;
}

function registerTextureMaterial(registry, key, material) {
  const materials = textureMaterials(registry, key);
  materials.add(material);
  material.addEventListener('dispose', () => materials.delete(material));
}

function updateSpriteTexture(name, texture) {
  sprites[name] = texture;
  for (const material of spriteMaterials.get(name) || []) {
    material.map = material.userData.resourceDirectionTexture || texture;
    material.needsUpdate = true;
  }
}

async function loadResourceStateAssets() {
  const loaded = new Map();
  const loadedFiles = [];
  try {
    const response = await fetch(`${INTERACTIVE_ASSET_ROOT}manifest.json`, { cache: 'force-cache' });
    if (!response.ok) {
      RESOURCE_STATE_ASSET_STATUS = {
        ...RESOURCE_STATE_ASSET_STATUS, state: 'unavailable',
        reason: `Interactive environment manifest returned HTTP ${response.status}`,
      };
      return RESOURCE_STATE_ASSET_STATUS;
    }
    const manifest = await response.json();
    if (manifest.schemaVersion !== 1 || manifest.packId !== 'environment.frontier-interactive'
      || !Array.isArray(manifest.files)) {
      throw new Error('Interactive environment manifest has an unsupported schema or pack ID');
    }
    const runtimeFiles = manifest.files.filter((entry) => entry?.role === 'runtime-image');
    const runtimeByPath = new Map(runtimeFiles.map((entry) => [entry.path, entry]));
    if (runtimeFiles.length !== REQUIRED_RESOURCE_STATE_FILES.length
      || runtimeByPath.size !== REQUIRED_RESOURCE_STATE_FILES.length
      || REQUIRED_RESOURCE_STATE_FILES.some((path) => !runtimeByPath.has(path))) {
      throw new Error('Interactive environment manifest must list exactly the ten required runtime images');
    }
    RESOURCE_STATE_ASSET_STATUS = {
      ...RESOURCE_STATE_ASSET_STATUS, packVersion: manifest.packVersion || null,
    };
    const oakDepletion = await loadOakDepletionAtlas().catch(error => {
      console.warn('Oak depletion atlas unavailable; using individual states', error.message);
      return null;
    });
    if (oakDepletion) loadedFiles.push(...oakDepletion.files.map(file => ({
      path: file.path, sha256: file.sha256, dimensionsPx: file.dimensionsPx,
    })));
    for (const path of REQUIRED_RESOURCE_STATE_FILES) {
      const stage = oakDepletionStage(path.replace(/\.webp$/, ''));
      const atlasTexture = oakDepletion?.texture(stage);
      if (atlasTexture) { loaded.set(path, atlasTexture); continue; }
      const result = await fetchVerifiedRuntimeImage(path, runtimeByPath.get(path),
        { assetRoot: INTERACTIVE_ASSET_ROOT, textureLoader, THREE });
      loaded.set(path, result.texture);
      loadedFiles.push({ path, sha256: result.sha256, dimensionsPx: result.dimensions });
    }

    for (const family of ['oak', 'berries']) {
      for (const stage of RESOURCE_VISUAL_STAGES) {
        const name = `${family}-${stage}`;
        const texture = meshyResourcesEnabled && stage === 'full' ? sprites[family] : loaded.get(`${name}.webp`);
        updateSpriteTexture(name, texture);
      }
    }
    for (const stage of ['earthwork', 'foundation']) {
      const texture = loaded.get(`construction-${stage}.webp`);
      constructionTextures.set(stage, texture);
      for (const material of constructionMaterials.get(stage) || []) {
        material.map = texture;
        material.color.setHex(0xffffff);
        material.opacity = 1;
        material.alphaTest = 0.04;
        material.needsUpdate = true;
      }
      for (const mesh of constructionInstances.get(stage) || []) {
        if (mesh.geometry.type === 'RingGeometry') {
          mesh.geometry.dispose();
          mesh.geometry = new THREE.PlaneGeometry(3, 3);
        }
      }
    }
    RESOURCE_STATE_ASSETS_AVAILABLE = true;
    RESOURCE_STATE_ASSET_STATUS = {
      ready: true,
      state: 'ready',
      packId: manifest.packId,
      packVersion: manifest.packVersion,
      loadedFiles,
      oakDepletionAtlas: Boolean(oakDepletion),
      reason: null,
    };
  } catch (error) {
    for (const texture of loaded.values()) texture.dispose();
    RESOURCE_STATE_ASSET_STATUS = {
      ...RESOURCE_STATE_ASSET_STATUS,
      ready: false,
      state: 'load-failed',
      loadedFiles,
      reason: error?.message || String(error),
    };
  }
  return RESOURCE_STATE_ASSET_STATUS;
}

export const resourceStateAssetsReady = loadResourceStateAssets();

const paintedGrounds = await loadPaintedMaterialAtlas().catch(error => {
  console.warn('Painted ground atlas unavailable; using individual textures', error.message);
  return null;
});
const grounds = new Map();
function groundTexture(material, definition, variant = false) {
  const name = groundTextureName(material, definition, variant, globalThis.location?.search ?? '');
  if (!name) return null;
  const painted = paintedGrounds?.texture(name);
  if (painted) return painted;
  if (grounds.has(name)) return grounds.get(name);
  const texture = textureLoader.load(`${ASSET_ROOT}${name}.webp?v=vaelora-ground-v2`);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.MirroredRepeatWrapping;
  texture.wrapT = THREE.MirroredRepeatWrapping;
  texture.anisotropy = 4;
  grounds.set(name, texture);
  return texture;
}

// Match the camera's world-up basis as well as its viewing normal. The shortest
// rotation from +Z matches the normal but adds about 19.7 degrees of screen roll.
const cameraFacing = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().lookAt(
  new THREE.Vector3(...CAMERA_VIEW_DIRECTION), new THREE.Vector3(), new THREE.Vector3(0, 1, 0),
));
const instanceDummy = new THREE.Object3D();
const spriteUpAxis = new THREE.Vector3(0, 1, 0);
const spriteYawRotation = new THREE.Quaternion();
const constructionGroundRotation = new THREE.Quaternion().setFromEuler(new THREE.Euler(-Math.PI / 2, 0, 0));

export function groundBaseMaterial(definition) {
  return TERRAIN_MATERIALS.includes(definition.terrainBase)
    ? definition.terrainBase : REGIONS[definition.region]?.ground || (definition.id === 'cinder-ridge' ? 'cinder' : 'meadow');
}

// Regional vegetation stays Underbough when an author paints grassy clearings.
export function environmentTheme(definition) {
  return definition.region === 'underbough' ? 'forest-floor' : groundBaseMaterial(definition);
}

function addGroundQuad(buffer, definition, x0, z0, x1, z1, y, alpha = [1, 1, 1, 1], heights = null) {
  const field=terrainHeightField(definition);
  if (field.raised && heights===null) {
    for(let row=0;row<definition.height;row++) for(let column=0;column<definition.width;column++) {
      const x=column-definition.width/2,z=row-definition.height/2;
      if(x<x0||z<z0||x+1>x1||z+1>z1) continue;
      addGroundQuad(buffer,definition,x,z,x+1,z+1,y,alpha,field.corners(column,row));
    }
    return;
  }
  const first = buffer.vertices.length / 3;
  for (const [i, [x, z, opacity]] of [
    [x0, z0, alpha[0]], [x1, z0, alpha[1]],
    [x0, z1, alpha[2]], [x1, z1, alpha[3]],
  ].entries()) {
    buffer.vertices.push(x, y+(heights?.[i]||0), z);
    // Every region samples the same world-space texture coordinates.
    buffer.uvs.push((x + definition.width / 2) / 12, (z + definition.height / 2) / 12);
    buffer.colors.push(1, 1, 1, opacity);
  }
  buffer.indices.push(first, first + 3, first + 1, first, first + 2, first + 3);
}

function finishGroundGeometry(buffer) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(buffer.vertices, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(buffer.uvs, 2));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(buffer.colors, 4));
  geometry.setIndex(buffer.indices);
  geometry.computeVertexNormals();
  const normals = geometry.getAttribute('normal');
  const colors = geometry.getAttribute('color');
  // Preserve the painted material's flat color while making slopes legible.
  for (let i = 0; i < normals.count; i++) {
    const shade = THREE.MathUtils.clamp(.85 + .15 * normals.getY(i)
      + .2 * (-.6 * normals.getX(i) + .4 * normals.getZ(i)), .68, 1.15);
    colors.setXYZ(i, shade, shade, shade);
  }
  return geometry;
}

function groundBuffer() {
  return { vertices: [], uvs: [], colors: [], indices: [] };
}

export function createGroundSurfaces(definition) {
  const base = groundBaseMaterial(definition);
  const stochastic = new URLSearchParams(globalThis.location?.search ?? '').get('terrainTiling') !== 'mirror';
  const freeRotation = new URLSearchParams(globalThis.location?.search ?? '').get('terrainRotation') === 'free';
  const groundMaterial = (options, role) => applyTerrainTextureSampling(
    new THREE.MeshBasicMaterial({ ...options, vertexColors: true }), definition.terrainSeed || 0, stochastic, freeRotation,
    stochastic ? groundTexture(role, definition, true) : null);
  const baseBuffer = groundBuffer();
  addGroundQuad(baseBuffer, definition,
    -definition.width / 2, -definition.height / 2,
    definition.width / 2, definition.height / 2, -0.025);
  const meshes = [new THREE.Mesh(
    finishGroundGeometry(baseBuffer),
    groundMaterial({ map: groundTexture(base, definition), color: 0xd2d4bd }, base),
  )];
  const waterGeometry = buildWaterSurfaceGeometry(definition);
  if (waterGeometry) {
    const motion = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)');
    const options = waterSurfaceOptions(globalThis.location?.search ?? '', motion?.matches === true);
    const water = createWaterSurfaceStudy(definition, {
      ...options, geometry: waterGeometry, getTime: () => performance.now() / 1000,
    });
    if (motion?.addEventListener) {
      const change = event => water.userData.setWaterStudyMotion(event.matches);
      motion.addEventListener('change', change);
      water.material.addEventListener('dispose', () => motion.removeEventListener('change', change));
    }
    water.renderOrder = 5;
    meshes.push(water);
  }
  function blendSurface(mask, y, renderOrder) {
    const buffer = groundBuffer();
    addGroundQuad(buffer, definition, -definition.width / 2, -definition.height / 2,
      definition.width / 2, definition.height / 2, y);
    const geometry = finishGroundGeometry(buffer);
    // Ground repeats in world units; the independent blend mask spans the map.
    const uv = geometry.getAttribute('uv');
    for (let vertex = 0; vertex < uv.count; vertex++) {
      uv.setXY(vertex, uv.getX(vertex) * 12 / definition.width,
        uv.getY(vertex) * 12 / definition.height);
    }
    const texture = groundTexture(mask.material, definition).clone();
    texture.repeat.set(definition.width / 12, definition.height / 12);
    const alphaMap = new THREE.DataTexture(mask.pixels, mask.width, mask.height, THREE.RGBAFormat);
    alphaMap.magFilter = THREE.LinearFilter;
    alphaMap.minFilter = THREE.LinearMipmapLinearFilter;
    alphaMap.generateMipmaps = true;
    alphaMap.needsUpdate = true;
    const mesh = new THREE.Mesh(geometry, groundMaterial({
      map: texture, alphaMap, color: 0xd2d4bd,
      transparent: true, depthWrite: false,
    }, mask.material));
    mesh.userData.ownedGroundTextures = [texture, alphaMap];
    mesh.renderOrder = renderOrder;
    return mesh;
  }
  const organicPaint = definition.region === 'underbough'
    && new URLSearchParams(globalThis.location?.search ?? '').get('paintEdges') !== 'legacy';
  for (const [layer, mask] of buildTerrainBlendMasks(definition, TERRAIN_MATERIALS, base, organicPaint).entries()) {
    meshes.push(blendSurface(mask, -0.019, GROUND_RENDER_ORDER + layer));
  }
  const forestMask = buildForestGroundMask(definition, forestGroundForBase(base));
  if (forestMask) {
    meshes.push(blendSurface(forestMask, -0.012,
      GROUND_RENDER_ORDER + TERRAIN_MATERIALS.length));
  }
  const bankShade = createShoreBankShade(definition);
  if (bankShade) {
    bankShade.renderOrder = -2; // After terrain paint, before haze, props and water.
    meshes.push(bankShade);
  }
  const atmosphere = new URLSearchParams(globalThis.location?.search ?? '');
  const atmosphereDefinition = { ...definition, terrainBase: base };
  if (groundMistEnabled(atmosphereDefinition, atmosphere.get('terrainAtmosphere'))) {
    const timeValue = atmosphere.get('terrainAtmosphereTime');
    const fixedTime = timeValue !== null && Number.isFinite(Number(timeValue)) ? Number(timeValue) : null;
    const mist = createGroundMistStudy(atmosphereDefinition, fixedTime, meshes[0].geometry);
    if (mist) meshes.push(mist);
  }
  const cliffFaces = createTerrainCliffFaces(definition, { base,
    texture: base === 'scree' ? groundTexture('scree', definition) : null, stochastic, freeRotation });
  if (cliffFaces) meshes.push(cliffFaces);
  meshes[0].userData.terrainSurface=true;
  return meshes;
}

function spriteGeometry(width, height, name) {
  if (meshyResourcesEnabled && (['oak', 'pine', 'berries', 'oak-full', 'berries-full'].includes(name) || directionalResource(name))) {
    // Preserve 128 px/world-unit and the baked (320,480) ground pivot.
    const geometry = new THREE.PlaneGeometry(5, 5, 1, 4);
    geometry.translate(0, 1.25, 0);
    const positions = geometry.attributes.position;
    const slope = Math.hypot(0.78, 0.78) / 1.12;
    for (let i = 0; i < positions.count; i++) {
      positions.setZ(i, -Math.min(0, positions.getY(i)) * slope);
    }
    positions.needsUpdate = true;
    return geometry;
  }
  const geometry = new THREE.PlaneGeometry(width, height);
  geometry.translate(0, height / 2, 0);
  return geometry;
}

function spriteMaterial(name) {
  if (!sprites[name]) {
    const direction = directionalResource(name);
    if (direction) sprites[name] = loadSprite(`./assets/environment/frontier-meshy-fixed-camera-v3/${direction[1]}/runtime/${direction[1]}-${direction[2]}.webp`);
    else {
    if (!spriteNames.includes(name)) throw new Error(`Unknown environment sprite: ${name}`);
    sprites[name] = loadSprite(`${ASSET_ROOT}${name}.webp`);
    }
  }
  const material = new THREE.MeshBasicMaterial({
    map: sprites[name],
    side: THREE.DoubleSide,
    transparent: true,
    alphaTest: 0.08,
    depthWrite: true,
    toneMapped: false,
  });
  if (oakDepletionStage(name)) applyOakDepletionSampling(material);
  registerTextureMaterial(spriteMaterials, name, material);
  return material;
}

export function createEnvironmentSprite(name, width, height, x, z) {
  const mesh = new THREE.Mesh(spriteGeometry(width, height, name), spriteMaterial(name));
  mesh.quaternion.copy(cameraFacing);
  mesh.position.set(x, groundHeight(x,z), z);
  return mesh;
}

export function createConstructionGroundInstances(stage, capacity) {
  const texture = constructionTextures.get(stage) || null;
  if (!['earthwork', 'foundation'].includes(stage) || !Number.isInteger(capacity) || capacity <= 0) return null;
  const mesh = new THREE.InstancedMesh(
    texture || stage === 'foundation'
      ? new THREE.PlaneGeometry(3, 3) : new THREE.RingGeometry(1.55, 1.92, 28),
    new THREE.MeshBasicMaterial({
      map: texture,
      color: texture ? 0xffffff : stage === 'earthwork' ? 0x72583b : 0x8c8170,
      transparent: true,
      alphaTest: texture ? 0.04 : 0,
      opacity: texture ? 1 : stage === 'earthwork' ? 0.52 : 0.42,
      depthTest: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false,
    }),
    capacity,
  );
  registerTextureMaterial(constructionMaterials, stage, mesh.material);
  textureMaterials(constructionInstances, stage).add(mesh);
  mesh.count = 0;
  mesh.visible = false;
  // Ground paint follows terrain/haze, before transparent building and unit
  // color. Actors do not write depth, so a late decal paints over their feet.
  mesh.renderOrder = -0.5;
  mesh.frustumCulled = false;
  return mesh;
}

export function updateConstructionGroundInstances(mesh, positions) {
  if (!mesh || positions.length > mesh.instanceMatrix.count) return false;
  for (let index = 0; index < positions.length; index++) {
    const point = positions[index];
    instanceDummy.position.set(point.x, groundHeight(point.x,point.z)+0.002, point.z);
    instanceDummy.quaternion.copy(constructionGroundRotation);
    instanceDummy.scale.setScalar(1);
    instanceDummy.updateMatrix();
    mesh.setMatrixAt(index, instanceDummy.matrix);
  }
  mesh.count = positions.length;
  mesh.visible = positions.length > 0;
  mesh.instanceMatrix.needsUpdate = true;
  return true;
}

export function createConnectedPalisadeGround(stage, capacity) {
  if (!['earthwork', 'foundation'].includes(stage)) return null;
  const texture = constructionTextures.get(stage) || null;
  const material = new THREE.MeshBasicMaterial({ map: texture,
    color: texture ? 0xffffff : 0x72583b, transparent: true, alphaTest: 0.04,
    opacity: texture ? 1 : 0.52, depthTest: true, depthWrite: false,
    side: THREE.DoubleSide, toneMapped: false });
  registerTextureMaterial(constructionMaterials, stage, material);
  return createPalisadeConstructionGroundMesh(material, capacity);
}

function registerLandVegetation(mesh) {
  mesh.geometry.computeBoundingBox();
  const matrices = mesh.instanceMatrix.array.slice(), bounds = [];
  const matrix = new THREE.Matrix4();
  for (let index = 0; index < mesh.count; index++) {
    matrix.fromArray(matrices, index * 16);
    const box = mesh.geometry.boundingBox.clone().applyMatrix4(matrix);
    bounds.push({ minX: box.min.x, maxX: box.max.x, minZ: box.min.z, maxZ: box.max.z });
  }
  mesh.userData.landVegetation = { matrices, bounds, hidden: new Uint8Array(mesh.count), signature: null };
}

// Only received building footprints affect scenery. Restore the original cards
// exactly when a footprint disappears; no economy or regrowth is inferred.
export function updateLandVegetationOccupation(objects, footprints = []) {
  const rows = footprints.filter(p => p && [p.x, p.z, p.width, p.depth].every(Number.isFinite)
    && p.width > 0 && p.depth > 0).map(p => [p.x, p.z, p.width, p.depth]);
  rows.sort((a, b) => a[0] - b[0] || a[1] - b[1] || a[2] - b[2] || a[3] - b[3]);
  const signature = JSON.stringify(rows), matrix = new THREE.Matrix4();
  let changed = 0;
  for (const mesh of objects) {
    const land = mesh.userData.landVegetation;
    if (!land || land.signature === signature) continue;
    let dirty = false;
    for (let index = 0; index < land.bounds.length; index++) {
      const b = land.bounds[index];
      const hidden = Number(rows.some(([x, z, width, depth]) => b.maxX >= x - width / 2
        && b.minX <= x + width / 2 && b.maxZ >= z - depth / 2 && b.minZ <= z + depth / 2));
      if (land.hidden[index] === hidden) continue;
      land.hidden[index] = hidden;
      if (hidden) matrix.makeScale(0, 0, 0);
      else matrix.fromArray(land.matrices, index * 16);
      mesh.setMatrixAt(index, matrix); dirty = true; changed++;
    }
    if (dirty) mesh.instanceMatrix.needsUpdate = true;
    land.signature = signature;
  }
  return changed;
}

const REGIONAL_WOOD_RESOURCES = Object.freeze({
  bellweather: {family: 'bellweather-field-maple', width: 3.05, height: 3.25},
  underbough: {family: 'underbough-root-oak', width: 3.1, height: 3.07655},
  sereward: {family: 'sereward-palm', width: 2.7, height: 3.8},
  'pale-meridian': {family: 'pale-meridian-conifer', width: 2.7, height: 3.8},
  siltmouths: {family: 'siltmouths-tidal-tree', width: 3.1, height: 3.0},
  vesperra: {family: 'vesperra-mistbark', width: 3.1, height: 3.4},
  'sombral-mere': {family: 'sombral-mere-merebloom', width: 2.6, height: 3.7},
  veyrholds: {family: 'veyrholds-highpine', width: 2.7, height: 3.4},
  ellionar: {family: 'ellionar-cultivated-palm', width: 2.7, height: 3.8},
  'ru-lora-fringe': {family: 'ru-lora-fringe-canopy', width: 3.43015, height: 3.4},
});

export function regionalWoodResourceProfile(definition) {
  return definition?.id === 'meshy-resource-review' ? null : REGIONAL_WOOD_RESOURCES[definition?.region] || null;
}

export function regionalFoodResourceProfile(definition) {
  return definition?.region === 'underbough' && definition.id !== 'meshy-resource-review'
    ? {family: 'underbough-thornberry', width: 1.8, height: 1.8 * 867 / 1176} : null;
}

export function createFoodResourceInstances(definition, stage, positions) {
  if (!RESOURCE_VISUAL_STAGES.includes(stage)) throw new Error(`Unknown food resource stage: ${stage}`);
  const profile = regionalFoodResourceProfile(definition);
  if (!profile) return createEnvironmentSpriteInstances(`berries-${stage}`, 2.55, 1.56, positions);
  const {family, width, height} = profile;
  const mesh = createEnvironmentSpriteInstances(stage === 'full' ? family : `${family}-${stage}`, width, height, positions);
  if (mesh) mesh.userData.resourceFoodFamily = family;
  return mesh;
}

export function createWoodResourceInstances(definition, stage, positions) {
  if (!RESOURCE_VISUAL_STAGES.includes(stage)) throw new Error(`Unknown wood resource stage: ${stage}`);
  const profile = regionalWoodResourceProfile(definition);
  if (!profile) return createEnvironmentSpriteInstances(`oak-${stage}`, 4.1, 3.75, positions);
  const {family, width, height} = profile;
  const mesh = createForestAtlasInstances(family, width, height, positions)
    || createEnvironmentSpriteInstances(stage === 'full' ? family : `${family}-${stage}`, width, height, positions);
  if (mesh) {
    mesh.userData.resourceWoodFamily = family;
    const atlas = mesh.userData.forestAtlas;
    if (atlas) {
      for (let index = 0; index < positions.length; index++) atlas.rects.setXYZW(index, ...atlas.frameRects[stage]);
      atlas.rects.needsUpdate = true;
    }
  }
  return mesh;
}

export function createEnvironmentSpriteInstances(name, width, height, positions) {
  if (positions.length === 0) return null;
  const plantSpec = assertPlantDimensions(name, width, height);
  const geometry = spriteGeometry(width, height, name);
  const viewPack = new URLSearchParams(globalThis.location?.search ?? '').get('plantViews') === 'legacy'
    ? null : name === 'vesperra-spiral-podvine' ? PODVINE_VIEW_PACK
    : name === 'vesperra-veilcap' ? VEILCAP_VIEW_PACK
    : name === 'ellionar-sunbloom' ? SUNBLOOM_VIEW_PACK : null;
  const material = viewPack ? new THREE.MeshBasicMaterial({side: THREE.DoubleSide,
    transparent: true, alphaTest: 0.08, depthWrite: true, toneMapped: false}) : spriteMaterial(name);
  let authoredPlantViews = null;
  if (viewPack) {
    const pack = viewPack;
    sprites[pack.url] ||= loadSprite(pack.url);
    material.map = sprites[pack.url];
    const rects = new THREE.InstancedBufferAttribute(new Float32Array(positions.length * 4), 4);
    const viewIndices = new Uint8Array(positions.length);
    for (let i = 0; i < positions.length; i++) {
      const p = positions[i], view = Math.floor(variation((p.cell ?? p.x * 71 + p.z * 137) + 1073) * 4);
      viewIndices[i] = view;
      const [x,y,w,h] = pack.rectsPx[view], [pageW,pageH] = pack.atlasSizePx;
      rects.setXYZW(i,(x+.5)/pageW,1-(y+h-.5)/pageH,(w-1)/pageW,(h-1)/pageH);
    }
    geometry.setAttribute('plantViewRect',rects);
    material.onBeforeCompile = shader => {
      shader.vertexShader = 'attribute vec4 plantViewRect;\n' + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace('#include <uv_vertex>',
        '#include <uv_vertex>\nvMapUv = plantViewRect.xy + vMapUv * plantViewRect.zw;');
      shader.uniforms.plantViewAtlasSize = {value:new THREE.Vector2(...pack.atlasSizePx)};
      shader.fragmentShader = 'uniform vec2 plantViewAtlasSize;\n' + shader.fragmentShader;
      const mapChunk = THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )',
        `textureLod(map,vMapUv,min(6.0,max(0.0,0.5*log2(max(
          dot(dFdx(vMapUv)*plantViewAtlasSize,dFdx(vMapUv)*plantViewAtlasSize),
          dot(dFdy(vMapUv)*plantViewAtlasSize,dFdy(vMapUv)*plantViewAtlasSize))))))`);
      shader.fragmentShader = shader.fragmentShader.replace('#include <map_fragment>',mapChunk);
    };
    material.customProgramCacheKey = () => 'vaelora-authored-views-v1-' + name;
    authoredPlantViews = {viewIndices,rects,frameIds:['front','right','rear','left'],measured3DCapture:false,
      pack, worked: new Uint8Array(positions.length)};
  }
  const family = meshyResourcesEnabled && /^(oak|berries)-full$/.exec(name)?.[1];
  if (family) {
    const atlasName = `${family}-direction-atlas`;
    sprites[atlasName] ||= loadSprite(`./assets/environment/frontier-meshy-fixed-camera-v3/${family}/${family}-atlas.webp`);
    material.map = sprites[atlasName];
    material.userData.resourceDirectionTexture = material.map;
    const rectangles = new THREE.InstancedBufferAttribute(new Float32Array(positions.length * 4), 4);
    for (let i = 0; i < positions.length; i++) {
      const point = positions[i];
      const heading = Math.floor(variation(point.x * 71 + point.z * 137 + 83) * 8);
      rectangles.setXYZW(i, (heading % 4) / 4, 1 - (Math.floor(heading / 4) + 1) / 2, 1 / 4, 1 / 2);
    }
    geometry.setAttribute('resourceViewRect', rectangles);
    material.onBeforeCompile = shader => {
      shader.vertexShader = 'attribute vec4 resourceViewRect;\n' + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace('#include <uv_vertex>',
        '#include <uv_vertex>\n#ifdef USE_MAP\nvMapUv = vMapUv * resourceViewRect.zw + resourceViewRect.xy;\n#endif');
    };
    material.customProgramCacheKey = () => 'resource-model-directions-v1';
  }
  const mesh = new THREE.InstancedMesh(geometry, material, positions.length);
  if (family) mesh.userData.resourceDirections = {family, rects: geometry.attributes.resourceViewRect};
  if (authoredPlantViews) mesh.userData.authoredPlantViews = authoredPlantViews;
  for (let index = 0; index < positions.length; index++) {
    const point = positions[index];
    setEnvironmentSpriteInstance(mesh, index, point.x, point.z,
      point.scale ?? 1, point.flip ?? false, point.yaw ?? 0);
  }
  mesh.instanceMatrix.needsUpdate = true;
  mesh.frustumCulled = false;
  if (plantSpec) mesh.userData.plantAsset = { id: name, ...plantSpec };
  return mesh;
}

function createWaterPlantInstances(name, width, depth, positions) {
  if (!positions.length) return null;
  const plantSpec = assertPlantDimensions(name, width, depth, true);
  const mesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(width, depth), spriteMaterial(name), positions.length);
  mesh.renderOrder = 7;
  mesh.frustumCulled = false;
  for (const [index, point] of positions.entries()) {
    instanceDummy.position.set(point.x, WATER_LEVEL + (plantSpec?.waterSurfaceLift ?? 0.008), point.z);
    instanceDummy.rotation.set(-Math.PI / 2, 0, (point.cell * 2.399963229728653) % (Math.PI * 2));
    instanceDummy.scale.set(point.flip ? -point.scale : point.scale, point.scale, point.scale);
    instanceDummy.updateMatrix();
    mesh.setMatrixAt(index, instanceDummy.matrix);
  }
  mesh.instanceMatrix.needsUpdate = true;
  mesh.userData.waterDecal = true;
  if (plantSpec) mesh.userData.plantAsset = { id: name, ...plantSpec };
  return mesh;
}

export function setEnvironmentSpriteInstance(mesh, index, x, z, scale, flip = false, yaw = 0) {
  // Authored views supply the turn; retain lighting and root registration on reset.
  if (mesh.userData.authoredPlantViews) { flip = false; yaw = 0; }
  instanceDummy.position.set(x, groundHeight(x,z), z);
  instanceDummy.quaternion.copy(cameraFacing);
  if (yaw) {
    spriteYawRotation.setFromAxisAngle(spriteUpAxis, yaw);
    instanceDummy.quaternion.multiply(spriteYawRotation);
  }
  instanceDummy.scale.set(flip ? -scale : scale, scale, scale);
  instanceDummy.updateMatrix();
  mesh.setMatrixAt(index, instanceDummy.matrix);
}

// Matches the authoritative six wood per forest cell in server.mjs.
// Hidden cells retain their last received stock; callers must not infer new stock.
export function setForestSpriteStock(slot, stock = 6) {
  const stage = resourceVisualStage(stock, 6);
  if (slot.understory) {
    const plant = slot.understory;
    const views = plant.mesh.userData.authoredPlantViews;
    if (views) {
      const worked = !!views.pack.workedRectsPx && stock > 0 && stock < 6;
      const low = stage === 'low' && !!views.pack.lowRectsPx;
      const frames = low ? views.pack.lowRectsPx : worked ? views.pack.workedRectsPx : views.pack.rectsPx;
      const [x,y,w,h] = frames[views.viewIndices[plant.index]];
      const [pw,ph] = views.pack.atlasSizePx;
      views.rects.setXYZW(plant.index,(x+.5)/pw,1-(y+h-.5)/ph,(w-1)/pw,(h-1)/ph);
      views.worked[plant.index] = low ? 2 : worked ? 1 : 0;
      views.rects.needsUpdate = true;
    }
    setEnvironmentSpriteInstance(plant.mesh, plant.index, plant.x, plant.z,
      stock <= 0 ? 0 : plant.scale, plant.flip, plant.yaw);
    plant.mesh.instanceMatrix.needsUpdate = true;
  }
  if (slot.atlas) {
    slot.atlas.rects.setXYZW(slot.index, ...slot.atlas.frameRects[stage]);
    slot.atlas.rects.needsUpdate = true;
    setEnvironmentSpriteInstance(slot.mesh, slot.index, slot.x, slot.z, slot.scale, slot.flip, slot.yaw);
    slot.mesh.instanceMatrix.needsUpdate = true;
  } else if (slot.stateMeshes) {
    for (const [key, mesh] of Object.entries(slot.stateMeshes)) {
      setEnvironmentSpriteInstance(mesh, slot.index, slot.x, slot.z,
        key === stage ? slot.scale : 0, slot.flip, slot.yaw);
      mesh.instanceMatrix.needsUpdate = true;
    }
  } else {
    setEnvironmentSpriteInstance(slot.mesh, slot.index, slot.x, slot.z,
      stock <= 0 ? 0 : slot.scale, slot.flip, slot.yaw);
    slot.mesh.instanceMatrix.needsUpdate = true;
  }
  return stage;
}

function variation(index) {
  const value = Math.sin(index * 127.1 + 17.7) * 43758.5453;
  return value - Math.floor(value);
}

export function addObstacleEnvironmentSprites(definition, halfX, halfZ, addObject) {
  const forestTreeSlots = new Map();
  const habitatDepth = ['underbough', 'vesperra'].includes(definition.region)
    && new URLSearchParams(globalThis.location?.search ?? '').get('forestHabitat') !== 'flat'
    ? forestHabitatDepth(definition) : null;
  // A small warm-field palette extension; other regions retain their existing trees.
  const bellweather = ['meadow', 'short-grass', 'long-grass', 'dry-grass']
    .includes(environmentTheme(definition));
  const veyrholds = environmentTheme(definition) === 'scree'
    && definition.id !== 'meshy-resource-review';
  const underbough = environmentTheme(definition) === 'forest-floor'
    && definition.id !== 'meshy-resource-review';
  const mosaicUnderbough = new URLSearchParams(globalThis.location?.search ?? '').get('forestSpecies') !== 'groves';
  const groupedUnderbough = new URLSearchParams(globalThis.location?.search ?? '').get('forestSpecies') !== 'scattered';
  const sereward = environmentTheme(definition) === 'sand'
    && definition.id !== 'meshy-resource-review';
  const ellionar = environmentTheme(definition) === 'garden-loam'
    && definition.id !== 'meshy-resource-review';
  const paleMeridian = ['snow', 'ice'].includes(environmentTheme(definition))
    && definition.id !== 'meshy-resource-review';
  const siltmouths = environmentTheme(definition) === 'tidal-mud'
    && definition.id !== 'meshy-resource-review';
  const vesperra = environmentTheme(definition) === 'jungle-loam'
    && definition.id !== 'meshy-resource-review';
  const sombralMere = environmentTheme(definition) === 'lunar-soil'
    && definition.id !== 'meshy-resource-review';
  const ruLora = environmentTheme(definition) === 'salt-crust'
    && definition.id !== 'meshy-resource-review';
  const livingFringe = definition.region === 'ru-lora-fringe' && vesperra;
  const pineName = livingFringe ? 'ru-lora-fringe-canopy' : sombralMere ? 'sombral-mere-merebloom' : vesperra ? 'vesperra-mistbark' : siltmouths ? 'siltmouths-tidal-tree' : paleMeridian ? 'pale-meridian-conifer' : ellionar ? 'ellionar-cultivated-palm' : sereward ? 'sereward-palm' : veyrholds ? 'veyrholds-highpine' : 'pine';
  const mapleName = sereward ? 'sereward-acacia' : underbough ? 'underbough-copperleaf'
    : bellweather ? 'bellweather-field-maple' : 'field-maple';
  const thicketName = ellionar ? 'ellionar-garden-hedge' : sereward ? 'sereward-scrub' : underbough ? 'underbough-bramble'
    : bellweather ? 'bellweather-hedgerow' : 'hazel-thicket';
  const pines = [];
  const oaks = [];
  const birches = [];
  const maples = [];
  const rootOaks = [];
  const hornbeams = [];
  const oldPlums = [];
  const hazelThickets = [];
  const outcrops = [];
  const brokenTrunks = [];
  const boulderClusters = [];
  const stoneFerns = [];
  const ridges = [];
  const ridgeCaps = [];
  const cliffs = [];
  const cliffCaps = [];
  for (const obstacle of definition.obstacles) {
    for (let row = obstacle.row; row < obstacle.row + obstacle.height; row++) {
      for (let column = obstacle.column; column < obstacle.column + obstacle.width; column++) {
        const index = row * definition.width + column;
        const x = column - halfX + 0.5;
        const z = row - halfZ + 0.5;
        if (obstacle.material === 'forest') {
          const treeType = variation(index + 7);
          const scaleVariation = variation(index + 31);
          const point = {
            cell: index,
            // Keep each harvest root inside its authoritative cell, but break
            // the visible plantation rows. Picking still uses this exact root.
            x: x + (variation(index) - 0.5) * 0.78,
            z: z + (variation(index + 19) - 0.5) * 0.78,
            flip: variation(index + 43) < 0.5,
            yaw: (variation(index + 53) - 0.5) * 0.3,
          };
          if (meshyResourcesEnabled && definition.id === 'meshy-resource-review') {
            point.scale = 0.72 + scaleVariation * 0.32;
            point.yaw = 0;
            (treeType < 0.45 ? oaks : pines).push(point);
            continue;
          }
          if (sombralMere) {
            point.scale = 0.76 + scaleVariation * 0.2;
            pines.push(point);
            continue;
          }
          if (vesperra) {
            point.scale = 0.68 + scaleVariation * 0.24;
            pines.push(point);
            continue;
          }
          if (siltmouths) {
            point.scale = 0.68 + scaleVariation * 0.24;
            pines.push(point);
            continue;
          }
          if (paleMeridian) {
            point.scale = 0.76 + scaleVariation * 0.2;
            pines.push(point);
            continue;
          }
          if (ellionar) {
            point.scale = treeType < 0.8
              ? 0.76 + scaleVariation * 0.2 : 0.62 + scaleVariation * 0.24;
            (treeType < 0.8 ? pines : hazelThickets).push(point);
            continue;
          }
          if (sereward) {
            if (treeType < 0.55) {
              point.scale = 0.76 + scaleVariation * 0.2;
              pines.push(point);
            } else if (treeType < 0.85) {
              point.scale = 0.68 + scaleVariation * 0.3;
              maples.push(point);
            } else {
              point.scale = 0.62 + scaleVariation * 0.24;
              hazelThickets.push(point);
            }
            continue;
          }
          if (underbough) {
            if (groupedUnderbough) {
              const species = underboughForestSpecies(column, row, definition.terrainSeed || 0, habitatDepth?.[index] ?? 1, mosaicUnderbough ? 6 : 10);
              point.scale = species === 'underbough-bramble' ? .62 + scaleVariation * .24 : .68 + scaleVariation * .3;
              ({'underbough-bramble':hazelThickets,'underbough-root-oak':rootOaks,
                'underbough-moss-hornbeam':hornbeams,'underbough-old-plum':oldPlums,
                'underbough-copperleaf':maples}[species]).push(point);
              continue;
            }
            // Broad olive oaks gather in loose groves, with copperleaf and
            // occasional bramble between them. Every root remains its wood cell.
            const grove = (Math.sin(column * .31 + row * .13)
              + Math.cos(row * .27 - column * .12) + 2) / 4;
            point.scale = treeType < .1
              ? .62 + scaleVariation * .24 : .68 + scaleVariation * .3;
            (treeType < .1 ? hazelThickets
              : treeType < .27 + grove * .2 ? rootOaks
                : treeType < .62 ? hornbeams : treeType < .82 ? oldPlums : maples).push(point);
            continue;
          }
          if (treeType < 0.2) {
            point.scale = 0.76 + scaleVariation * 0.2;
            oaks.push(point);
          } else if (treeType < 0.4) {
            point.scale = 0.76 + scaleVariation * 0.2;
            pines.push(point);
          } else if (treeType < 0.6) {
            point.scale = 0.68 + scaleVariation * 0.3;
            birches.push(point);
          } else if (treeType < 0.8) {
            point.scale = 0.68 + scaleVariation * 0.3;
            maples.push(point);
          } else {
            point.scale = 0.62 + scaleVariation * 0.24;
            hazelThickets.push(point);
          }
        } else if (obstacle.material === 'stone') {
          const vertical = obstacle.height >= obstacle.width;
          const centerLine = vertical
            ? column === obstacle.column + Math.floor(obstacle.width / 2)
            : row === obstacle.row + Math.floor(obstacle.height / 2);
          const along = vertical ? row - obstacle.row : column - obstacle.column;
          const barrierLength = vertical ? obstacle.height : obstacle.width;
          const atBarrierEnd = along === 0 || along === barrierLength - 1;
          if (centerLine && (along % 2 === 0 || atBarrierEnd)) {
            const point = {
              x, z,
              scale: 0.88 + variation(index + 13) * 0.24,
              flip: variation(index + 41) < 0.5,
            };
            if ((obstacle.elevation ?? 1.12) < 1) {
              if (variation(index + 59) < 0.5) {
                const cluster = ruLora && variation(index + 83) < 0.65 ? stoneFerns : boulderClusters;
                cluster.push({
                  ...point,
                  scale: 0.82 + variation(index + 61) * 0.3,
                });
              } else (ruLora && variation(index + 97) < 0.35 ? brokenTrunks : outcrops).push(point);
            } else if ((obstacle.elevation ?? 1.12) >= 1.75) {
              if (atBarrierEnd) {
                cliffCaps.push({
                  ...point,
                  scale: 0.92 + variation(index + 73) * 0.16,
                  flip: along === 0,
                });
              } else cliffs.push(point);
            } else if (atBarrierEnd) {
              ridgeCaps.push({
                ...point,
                scale: 0.88 + variation(index + 71) * 0.22,
                flip: along === 0,
              });
            } else ridges.push(point);
          }
        }
      }
    }
  }
  const mutedCopperleaf = underbough && new URLSearchParams(globalThis.location?.search ?? '').get('forestCopperleaf') !== 'original';
  const leafyHornbeam = underbough && new URLSearchParams(globalThis.location?.search ?? '').get('forestCanopy') !== 'original';
  const layeredForestMargin = underbough && new URLSearchParams(globalThis.location?.search ?? '').get('forestEdges') === 'layered';
  const youngHornbeams = [];
  const ageMode = new URLSearchParams(globalThis.location?.search ?? '').get('forestAges');
  if (underbough && ageMode === 'pockets') {
    // Small regeneration patches retain mature crowns and other species sizes.
    const seeded = key => { const value = Math.sin(key * 127.1 + 17.7) * 43758.5453; return value - Math.floor(value); };
    for (let i = hornbeams.length - 1; i >= 0; i--) {
      const point = hornbeams[i], column = point.cell % definition.width, row = Math.floor(point.cell / definition.width);
      const patch = Math.floor(column / 4) * 313 + Math.floor(row / 4) * 571 + (definition.terrainSeed || 0) * .13;
      if (seeded(patch + 211) < .3 && seeded(point.cell + 59) < .65) {
        hornbeams.splice(i, 1); youngHornbeams.push({...point});
      }
    }
  }
  if (underbough && ['irregular', 'young'].includes(ageMode)) {
    const canopyPoints = [...rootOaks, ...hornbeams, ...oldPlums, ...maples];
    const factors = forestAgeFactors(canopyPoints, definition.terrainSeed || 0);
    if (ageMode === 'young') {
      // Authored age forms stay in their own species groves. Other species
      // retain the earlier scale experiment until their young forms exist.
      for (const points of [hornbeams]) {
        for (let i = points.length - 1; i >= 0; i--) {
          const point = points[i], factor = factors.get(point.cell);
          if (factor < 1) {
            points.splice(i, 1);
            youngHornbeams.push({...point, scale: point.scale * (factor / .725)});
          } else point.scale *= factor;
        }
      }
      for (const point of [...rootOaks, ...oldPlums, ...maples]) point.scale *= factors.get(point.cell);
    } else for (const point of canopyPoints) point.scale *= factors.get(point.cell);
  }
  for (const [name, width, height, points] of [
    [pineName, livingFringe ? 3.43015 : sombralMere ? 2.6 : vesperra || siltmouths ? 3.1 : paleMeridian || ellionar || sereward || veyrholds ? 2.7 : 2.25, sombralMere ? 3.7 : siltmouths ? 3.0 : paleMeridian || ellionar || sereward ? 3.8 : 3.4, pines],
    ['oak', 3.05, 2.86, oaks],
    ['underbough-young-hornbeam', 2.1 * 868 / 1060, 2.1 * 1082 / 1060, youngHornbeams],
    ['underbough-root-oak', 3.1, 3.07655, rootOaks],
    [leafyHornbeam ? 'underbough-leafy-hornbeam-v2' : 'underbough-moss-hornbeam', leafyHornbeam ? 3.651379638439581 * 1062 / 1066 : 3.6 * 1013 / 1245, leafyHornbeam ? 3.651379638439581 : 3.6, hornbeams],
    ['underbough-old-plum', 2.85 * 1220 / 1135, 2.85, oldPlums],
    ['silver-birch', 2.3, 3.45, birches],
    [mutedCopperleaf ? 'underbough-muted-copperleaf-v2' : mapleName, mutedCopperleaf ? 3.05 * 1312 / 1289 : sereward ? 3.5 : 3.05, mutedCopperleaf ? 3.25 * 1199 / 1171 : sereward ? 2.85 : 3.25, maples],
    [thicketName, ellionar ? 2.8 : sereward ? 2.6 : 3.1, ellionar ? 1.8 : sereward ? 1.7 : 2.07, hazelThickets],
    [ruLora ? 'ru-lora-fiendwood' : paleMeridian ? 'pale-meridian-violet-lichen' : veyrholds ? 'veyrholds-ironlichen-outcrop' : 'rock-outcrop', ruLora ? 3.3 : paleMeridian ? 2.8818 : 3.5, ruLora ? 3.2 : paleMeridian ? 1.5 : 2.2, outcrops],
    ['ru-lora-broken-trunk', 1.655, 2.3, brokenTrunks],
    ['ru-lora-stone-fern', 2.511, 1.65, stoneFerns],
    [ruLora ? 'ru-lora-god-bone' : 'rock-boulder-cluster', ruLora ? 2.83966 : 2.7, ruLora ? 1.65 : 1.8, boulderClusters],
    ['basalt-ridge', 3.6, 3.05, ridges],
    ['basalt-ridge-cap', 3.4, 2.25, ridgeCaps],
    ['cliff', 4.2, 4.6, cliffs],
    ['cliff-end-cap', 4.2, 4.6, cliffCaps],
  ].flatMap(([name, width, height, points]) => {
    if (!meshyResourcesEnabled || !['oak', 'pine'].includes(name)) return [[name, width, height, points]];
    return Array.from({length: 8}, (_, heading) => [`${name}-view-${String(heading).padStart(2, '0')}`, width, height,
      points.filter(point => Math.floor(variation(point.cell + 83) * 8) === heading)
        .map(point => ({...point, flip: false, yaw: 0, modelYawDegrees: heading * 45}))]);
  })) {
    if (habitatDepth) for (const point of points) {
      if (!Number.isInteger(point.cell)) continue;
      point.habitatDepth = habitatDepth[point.cell];
      point.scale *= layeredForestMargin
        ? forestMarginCanopyFactor(point.habitatDepth, point.cell % definition.width, Math.floor(point.cell / definition.width), definition.terrainSeed || 0)
        : forestCanopyFactor(point.habitatDepth);
    }
    const mesh = createForestAtlasInstances(name, width, height, points)
      || createEnvironmentSpriteInstances(name, width, height, points);
    if (!mesh) continue;
    let stateMeshes;
    if (!mesh.userData.forestAtlas && ['bellweather-field-maple', 'sereward-palm', 'pale-meridian-conifer', 'siltmouths-tidal-tree', 'ru-lora-fringe-canopy', 'vesperra-mistbark', 'sombral-mere-merebloom', 'underbough-copperleaf', 'underbough-bramble', 'underbough-root-oak', 'underbough-moss-hornbeam', 'underbough-young-hornbeam', 'underbough-leafy-hornbeam-v2', 'underbough-muted-copperleaf-v2', 'underbough-old-plum', 'veyrholds-highpine', 'ellionar-cultivated-palm', 'ellionar-garden-hedge', 'sereward-acacia', 'sereward-scrub', 'bellweather-hedgerow'].includes(name)) {
      stateMeshes = { full: mesh };
      for (const stage of ['worked', 'low', 'depleted']) {
        const stateMesh = createEnvironmentSpriteInstances(`${name}-${stage}`, width, height,
          points.map((point) => ({ ...point, scale: 0 })));
        stateMeshes[stage] = stateMesh;
        addObject(stateMesh);
      }
    }
    for (let index = 0; index < points.length; index++) {
      const point = points[index];
      if (!Number.isInteger(point.cell)) continue;
      forestTreeSlots.set(point.cell, { mesh, index, ...point, family: directionalResource(name)?.[1] || name, stateMeshes, atlas: mesh.userData.forestAtlas });
    }
    addObject(mesh);
  }
  const understoryAsset = definition.id === 'meshy-resource-review' ? null
    : livingFringe ? ['ru-lora-fringe-broadleaf', 1.09551, 0.72] : {
    'jungle-loam': ['vesperra-shade-fern', 1.07475, 0.72],
    'tidal-mud': ['siltmouths-silver-reed', 1.29076, 1.05],
    'snow': ['pale-meridian-silver-moss', 0.83027, 0.45],
    'ice': ['pale-meridian-silver-moss', 0.83027, 0.45],
    'lunar-soil': ['sombral-mere-lunewort', 0.88203, 1.15],
    'forest-floor': ['underbough-rootward-fungus', 1.08404, 0.65],
    'scree': ['veyrholds-ridgegrass', 1.15218, 0.8],
    'garden-loam': ['ellionar-sunbloom', 0.88654, 0.85],
    'sand': ['sereward-succulent', 0.97338, 0.75],
  }[environmentTheme(definition)] || (bellweather ? ['bellweather-meadow-herbs', 1.15561, 0.72] : null);
  if (understoryAsset) {
    const seed = Math.trunc(definition.terrainSeed || 0) * 131;
    const insideCell = (value, center) => Math.max(center - 0.45, Math.min(center + 0.45, value));
    // Decorative understory occupies existing forest cells only. Clearing follows
    // received cell stock, so it cannot cover a newly traversable cleared cell.
    const plants = [...forestTreeSlots.values()].filter(slot => variation(slot.cell + seed + 107)
      < (slot.habitatDepth === 1 ? 0.5 : slot.habitatDepth >= 3 ? 0.18 : 0.28))
      .map(slot => ({ cell: slot.cell,
        x: insideCell(slot.x + (variation(slot.cell + seed + 109) - 0.5) * 0.32 + (sombralMere ? 0.18 : 0),
          slot.cell % definition.width - halfX + 0.5),
        z: insideCell(slot.z + (variation(slot.cell + seed + 113) - 0.5) * 0.32 + (sombralMere ? 0.18 : 0),
          Math.floor(slot.cell / definition.width) - halfZ + 0.5),
        scale: 0.8 + variation(slot.cell + seed + 127) * 0.25,
        flip: slot.flip, yaw: slot.yaw }));
    const alternate = {
      'bellweather-meadow-herbs': ['bellweather-meadow-clover', 0.79703, 0.65],
      'vesperra-shade-fern': ['vesperra-shade-fern-02', 1.05628, 0.72],
      'sereward-succulent': ['sereward-succulent-02', 1.05931, 0.75],
      'underbough-rootward-fungus': ['underbough-rootward-fungus-02', 0.65989, 0.65],
      'pale-meridian-silver-moss': ['pale-meridian-frostberry', 1.10553, 0.8],
      'sombral-mere-lunewort': ['sombral-mere-noctilune', 1.0104, 0.95],
      'siltmouths-silver-reed': ['siltmouths-marsh-tuber', 1.01564, 0.85],
      'veyrholds-ridgegrass': ['veyrholds-suncrest', 0.80124, 0.7],
      'ellionar-sunbloom': ['ellionar-garden-vine', 0.96324, 0.65],
    }[understoryAsset[0]];
    const variants = alternate ? [understoryAsset, alternate] : [understoryAsset];
    if (underbough) variants.push(['underbough-low-hazel', 1.13959, 0.7]);
    if (understoryAsset[0] === 'vesperra-shade-fern') variants.push(['vesperra-veilcap', 0.61614, 0.65], ['vesperra-spiral-podvine', 1.10431, 0.55]);
    for (let variant = 0; variant < variants.length; variant++) {
      const selected = variants.length === 1 ? plants : plants.filter(plant =>
        Math.floor(variation(plant.cell + seed + 149) * variants.length) === variant);
      if (!selected.length) continue;
      const [name, width, height] = variants[variant];
      const mesh = createEnvironmentSpriteInstances(name, width, height, selected);
      if (mesh) {
        mesh.userData.forestUnderstory = true;
        mesh.userData.understoryAsset = name;
        selected.forEach((plant, index) => {
          forestTreeSlots.get(plant.cell).understory = { mesh, index, ...plant };
        });
        addObject(mesh);
      }
    }
  }
  if (vesperra) {
    for (const { name, positions } of junglePlantGroups(definition, environmentTheme(definition))) {
      const spec = PLANT_ASSETS[name];
      const plants = createEnvironmentSpriteInstances(name, spec.worldWidth, spec.worldHeight, positions);
      if (plants) {
        plants.userData.jungleVegetation = true;
        registerLandVegetation(plants);
        addObject(plants);
      }
    }
  }
  if (siltmouths) {
    for (const { name, positions } of marshPlantGroups(definition, environmentTheme(definition))) {
      const spec = PLANT_ASSETS[name];
      const plants = createEnvironmentSpriteInstances(name, spec.worldWidth, spec.worldHeight, positions);
      if (plants) {
        plants.userData.marshVegetation = true;
        registerLandVegetation(plants);
        addObject(plants);
      }
    }
  }
  if (sombralMere) {
    for (const { name, positions } of lunarPlantGroups(definition, environmentTheme(definition))) {
      const spec = PLANT_ASSETS[name];
      const plants = createEnvironmentSpriteInstances(name, spec.worldWidth, spec.worldHeight, positions);
      if (plants) {
        plants.userData.lunarVegetation = true;
        registerLandVegetation(plants);
        addObject(plants);
      }
    }
  }
  if (veyrholds) {
    for (const { name, positions } of ridgePlantGroups(definition, environmentTheme(definition))) {
      const spec = PLANT_ASSETS[name];
      const plants = createEnvironmentSpriteInstances(name, spec.worldWidth, spec.worldHeight, positions);
      if (plants) {
        plants.userData.ridgeVegetation = true;
        registerLandVegetation(plants);
        addObject(plants);
      }
    }
  }
  if (bellweather) {
    for (const { name, positions } of meadowPlantGroups(definition, environmentTheme(definition))) {
      const spec = PLANT_ASSETS[name];
      const flowers = createEnvironmentSpriteInstances(name, spec.worldWidth, spec.worldHeight, positions);
      if (flowers) {
        flowers.userData.meadowVegetation = true;
        registerLandVegetation(flowers);
        addObject(flowers);
      }
    }
  }
  if (sereward) {
    for (const { name, positions } of drylandPlantGroups(definition, environmentTheme(definition))) {
      const spec = PLANT_ASSETS[name];
      const plants = createEnvironmentSpriteInstances(name, spec.worldWidth, spec.worldHeight, positions);
      if (plants) {
        plants.userData.drylandVegetation = true;
        registerLandVegetation(plants);
        addObject(plants);
      }
    }
  }
  if (paleMeridian) {
    for (const { name, positions } of snowPlantGroups(definition, environmentTheme(definition))) {
      const spec = PLANT_ASSETS[name];
      const plants = createEnvironmentSpriteInstances(name, spec.worldWidth, spec.worldHeight, positions);
      if (plants) {
        plants.userData.snowVegetation = true;
        registerLandVegetation(plants);
        addObject(plants);
      }
    }
  }
  if (ellionar) {
    for (const { name, positions } of gardenPlantGroups(definition, environmentTheme(definition))) {
      const spec = PLANT_ASSETS[name];
      const flowers = createEnvironmentSpriteInstances(name, spec.worldWidth, spec.worldHeight, positions);
      if (flowers) {
        flowers.userData.gardenVegetation = true;
        registerLandVegetation(flowers);
        addObject(flowers);
      }
    }
  }
  if (siltmouths || sombralMere) {
    // The current water renderer is flat: omit raised roots until it supports
    // elevated water surfaces. Water cells are already blocked by the map.
    const field = terrainHeightField(definition);
    const shorePlants = shorePlantPositions(definition).filter(p => field.sample(p.x, p.z) === 0);
    const shore = siltmouths
      ? createEnvironmentSpriteInstances('siltmouths-silver-reed', 1.29076, 1.05, shorePlants)
      : createWaterPlantInstances('sombral-mere-mirelily', 0.75, 0.7229, shorePlants);
    if (shore) {
      if (siltmouths) shore.position.y = WATER_LEVEL;
      if (siltmouths) registerLandVegetation(shore);
      shore.userData.shoreVegetation = true;
      addObject(shore);
    }
  }
  return forestTreeSlots;
}
