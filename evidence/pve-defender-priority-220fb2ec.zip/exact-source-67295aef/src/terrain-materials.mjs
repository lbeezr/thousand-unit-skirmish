export const TERRAIN_MATERIALS = [
  'meadow',
  'short-grass',
  'long-grass',
  'forest-floor',
  'dirt',
  'sand',
  'scree',
  'cinder',
  'snow',
  'ice',
  'tidal-mud',
  'jungle-loam',
  'lunar-soil',
  'dry-grass',
  'garden-loam',
  'salt-crust',
];

export const TERRAIN_COLORS = {
  'meadow': '#849543',
  'short-grass': '#99973b',
  'long-grass': '#506228',
  'forest-floor': '#5b3926',
  'dirt': '#b28049',
  'sand': '#e29d6a',
  'scree': '#555552',
  'cinder': '#5f5458',
  'snow': '#d8e1f2',
  'ice': '#264560',
  'tidal-mud': '#747262',
  'jungle-loam': '#31331a',
  'lunar-soil': '#595c5d',
  'dry-grass': '#be9951',
  'garden-loam': '#694221',
  'salt-crust': '#7b6d6e',
};

// Root cover follows the region's existing ground palette; no new map rule.
export function forestGroundForBase(base) {
  const regional = {
    sand: 'dirt', scree: 'scree', 'garden-loam': 'garden-loam',
    snow: 'snow', ice: 'snow', 'tidal-mud': 'tidal-mud',
    'jungle-loam': 'jungle-loam', 'lunar-soil': 'lunar-soil',
  };
  return regional[base] || 'forest-floor';
}
