import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { createPveHeadlessFixture } from '/workspace/pve-defender-priority-review-c485aaee/scripts/pve-headless-fixture.mjs';
import { loadDefenderAssault } from '/workspace/pve-defender-priority-review-c485aaee/scripts/pve-defender-assault-case.mjs';
import { toOpponentObservation } from '/workspace/pve-defender-priority-review-c485aaee/src/pve-opponent.mjs';

const root = '/workspace/pve-defender-priority-review-c485aaee', review = new URL('.', import.meta.url).pathname;
const overlay = path.join(review, 'old-priority-overlay'); await mkdir(overlay, { recursive: true });
const source = await readFile(`${root}/src/pve-skirmish-targets.mjs`, 'utf8');
const current = `    // A disclosed combatant already in range of this assault can kill it while
    // it attacks a producer. Clear that immediate threat before the building.
    const immediate = unit.kind !== 'worker' && UNIT_DEFINITIONS[unit.kind].capabilities.includes('attack')
      && soldiers.some(soldier => Math.hypot(unit.x - soldier.x, unit.z - soldier.z)
        <= UNIT_DEFINITIONS[unit.kind].combat.range);
    candidates.push({ key: \`unit:\${identity(unit)}\`, priority: immediate ? -1 : 1, type: 'attack',`;
assert.equal(source.split(current).length - 1, 1);
const inverse = source.replace(current, "    candidates.push({ key: `unit:${identity(unit)}`, priority: 1, type: 'attack',");
const absolute = value => value.replace(/from '(\.\/?[^']+)'/g, (_, name) =>
  `from '${pathToFileURL(path.resolve(root, 'src', name)).href}'`);
await writeFile(path.join(overlay, 'pve-skirmish-targets.mjs'), absolute(inverse));
let opponent = absolute(await readFile(`${root}/src/pve-opponent.mjs`, 'utf8'));
const canonical = pathToFileURL(`${root}/src/pve-skirmish-targets.mjs`).href;
assert.equal(opponent.split(canonical).length - 1, 1);
opponent = opponent.replace(canonical, pathToFileURL(path.join(overlay, 'pve-skirmish-targets.mjs')).href);
await writeFile(path.join(overlay, 'pve-opponent.mjs'), opponent);
const { createDeterministicPolicy } = await import(pathToFileURL(path.join(overlay, 'pve-opponent.mjs')).href);
const results = [];
for (const mode of ['authored', 'skirmish']) {
  const input = await loadDefenderAssault(mode), fixture = await createPveHeadlessFixture(input.map, input.nativeIdentity), r = fixture.replay;
  try {
    r.restore(input.loss);
    const policies = input.seeds.map(seed => createDeterministicPolicy(seed, input.policyIdentity));
    const trace = [], views = [], startHp = input.loss.state.homeTownCenters[0].hp;
    // Match the historical helper's per-tick checkpoint observer exactly.
    // This is a negative witness under that observer, not normal publication qualification.
    for (let i = 0; i < 1800; i++) {
      if (i % 30 === 0) for (const team of [0, 1]) {
        const observation = toOpponentObservation(r.observe(team), team, input.map);
        views.push({ tick: observation.tick, team, observation });
        for (const command of policies[team].next(observation)) {
          if (command.type === 'attack') assert(observation.units.visibleEnemies.some(u => u.hp > 0 && u.id === command.targetId && u.generation === command.targetGeneration));
          if (command.type === 'attackBuilding') assert(observation.buildings.visibleEnemies.some(b => b.hp > 0 && b.id === command.buildingId));
          const notices = await r.order(team, command); r.drain();
          assert(!notices.some(n => /REJECTED|FAILED|UNREACHABLE/.test(n.message || '')));
          trace.push({ tick: observation.tick, team, command, notices });
        }
      }
      r.step(); r.checkpoint();
    }
    const final = r.checkpoint(), defenderHp = final.state.units.find(u => u.id === input.defenderId).hp;
    const frontline = input.frontlineIds.map(id => ({ id, hp: final.state.units.find(u => u.id === id).hp }));
    assert.equal(defenderHp, 100); assert(frontline.every(u => u.hp === 0));
    assert.equal(final.state.matchWinner, -1);
    assert(!trace.some(t => t.team === 1 && t.command.type === 'attack' && t.command.targetId === input.defenderId));
    const summary = { mode, source: 'c485aaee69ca018250becce24a5dda40ed77e22d',
      overlay: 'Only the new immediate-unit priority clause reversed; all other policy/native bytes unchanged.',
      cadence: 'Historical per-tick checkpoint observer; pending correction to native3 boundaries.',
      defenderHp, frontline, townCenterDamage: startHp - final.state.homeTownCenters[0].hp,
      orders: trace.length, rejected: 0, winner: final.state.matchWinner,
      finalSHA256: createHash('sha256').update(JSON.stringify(final)).digest('hex') };
    await writeFile(path.join(review, `old-priority-${mode}.json`), JSON.stringify({ summary, input, trace, views, final }));
    results.push(summary); console.log(JSON.stringify(summary));
  } finally { await fixture.dispose(); }
}
await writeFile(path.join(review, 'old-priority-summary.json'), JSON.stringify(results, null, 2));
