from pathlib import Path
import json
import hashlib

ROOT = Path('/workspace/pve-67295aef-diagnosis-2026-10-05-evidence')
OUT = Path(__file__).parent
load = lambda p: json.loads(p.read_text())
results = []
for mode in ['authored', 'skirmish']:
    for flavor in ['baseline', 'candidate']:
        first = load(ROOT / f'priority-{mode}-{flavor}-0.json')
        second = load(ROOT / f'priority-{mode}-{flavor}-1.json')
        for field in ['initialHash', 'initialObservation', 'trace', 'samples', 'finalHash', 'defenderDeath']:
            assert first[field] == second[field], (mode, flavor, field)
        assert all(row['tick'] % 30 == 0 for row in first['trace'])
        assert first['samples'][0]['tick'] == 108000 and first['samples'][-1]['tick'] == 109800
        older = load(ROOT / 'superseded-per-tick-probe' / f'priority-{mode}-{flavor}-0.json')
        for field in ['initialHash', 'initialObservation', 'trace', 'samples']:
            assert older[field] == first[field], (mode, flavor, field)
        if flavor == 'baseline':
            assert first['finalHash'] != older['finalHash']
            assert first['samples'][-1]['defender'] == 100
            assert all(row['hp'] == 0 for row in first['samples'][-1]['frontline'])
            negative = load(OUT / f'old-priority-{mode}.json')
            assert first['finalHash'] == negative['summary']['finalSHA256']
            assert first['trace'] == negative['trace']
            assert first['defenderDeath'] is None
        else:
            assert first['finalHash'] == older['finalHash']
            assert first['defenderDeath'] == 108078 and older['defenderDeath'] == 108077
            assert first['samples'][-1]['defender'] == 0
            assert sum(row['hp'] for row in first['samples'][-1]['frontline']) == 304
        results.append({'mode': mode, 'flavor': flavor, 'wholeRepeatFieldsEqual': True,
                        'commandAndPhysicalSamplesEqualToSupersededObserver': True,
                        'fullFinalHashEqualToSupersededObserver': first['finalHash'] == older['finalHash'],
                        'nativeBoundaryFinalHash': first['finalHash']})
    baseline = load(ROOT / f'priority-{mode}-baseline-0.json')
    candidate = load(ROOT / f'priority-{mode}-candidate-0.json')
    assert baseline['initialHash'] == candidate['initialHash']
    assert baseline['samples'][-1]['banks'] == candidate['samples'][-1]['banks']
    for temperature in ['warm', 'cold']:
        author = load(ROOT / 'corrected-native-cadence' / f'defender-{mode}-{temperature}.json')
        independent = load(OUT / f'defender-{mode}-{temperature}.json')
        assert author == independent, (mode, temperature)
        result = independent['result']
        assert result['stages']['defenderLastAlive'] == 108075
        assert result['stages']['defenderDeath'] == 108078
        assert result['stages']['resume'] == 108090
        assert result['final']['state']['matchWinner'] == -1
        damage = result['initialTownCenterHp'] - result['finalTownCenterHp']
        assert abs(damage - (500.4 if temperature == 'warm' else 498.6)) < 1e-8
        final_hash = hashlib.sha256(json.dumps(result['final'], separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
        results.append({'mode': mode, 'temperature': temperature, 'independentEqualsAuthorWholeNativeReplay': True,
                        'observedDeathWindow': {'lastAlive': 108075, 'firstDead': 108078},
                        'resume': 108090, 'actualTownCenterDamage': damage,
                        'unresolvedWinner': -1, 'finalObjectSha256PythonCompactJson': final_hash})
receipt = {'source': '068822a90e7ae6cc285d1c5e0c2ad8600a4627ad', 'results': results,
           'limit': 'Baseline full final authority differs between observers. No general authority or cadence invariance claim.'}
(OUT / 'cadence-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
