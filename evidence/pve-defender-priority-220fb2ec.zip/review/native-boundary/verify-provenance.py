from pathlib import Path
import base64
import collections
import gzip
import hashlib
import json
import subprocess
import zipfile

HEAD = '068822a90e7ae6cc285d1c5e0c2ad8600a4627ad'
BASE = 'b02ea4faae890e97af7ca520d9da189aa9b86a3c'
ROOT = Path('/workspace/pve-67295aef-diagnosis-2026-10-05-evidence')
COPY = Path('/workspace/pve-defender-priority-review-068822a9')
REPO = Path('/workspace/pve-scout-completion')
OUT = Path(__file__).parent
digest = lambda b: hashlib.sha256(b).hexdigest()
archive = ROOT / 'input/cpu-qualification-67295aef.zip'
archive_bytes = archive.read_bytes()
provenance = json.loads((COPY / 'scripts/fixtures/pve-defender-assault/provenance.json').read_text())
assert len(archive_bytes) == 769023
assert digest(archive_bytes) == provenance['archiveSha256']
checks = []
with zipfile.ZipFile(archive) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == 40
    manifest = json.loads(z.read('MANIFEST.json'))
    assert manifest['source'] == provenance['source']
    assert len(manifest['entries']) == 39
    assert set(names) == {'MANIFEST.json'} | {row['path'] for row in manifest['entries']}
    for row in manifest['entries']:
        data = z.read(row['path'])
        assert len(data) == row['bytes'], row['path']
        assert digest(data) == row['sha256'], row['path']
        assert (ROOT / 'input/extracted' / row['path']).read_bytes() == data, row['path']
    report = json.loads(z.read('report.json'))
    assert report['source'] == {'revision': provenance['source'], 'dirty': False}
    assert report['status'] == 'failed' and report['fullCpuSuitePassed'] is False
    assert report['passedCount'] == 1105 and report['unrunCount'] == 217
    statuses = collections.Counter(row['status'] for row in report['checks'])
    assert statuses['failed'] == 1
    for descriptor in provenance['checkpoints']:
        mode = descriptor['mode']
        prefix = f'tiny-failure-evidence/tiny-{mode}-20260925-0/'
        record_bytes = z.read(prefix + 'record.json')
        record = json.loads(record_bytes)
        compressed_record = z.read(prefix + 'record.json.gz')
        envelope = json.loads(z.read(prefix + 'envelope.json'))
        assert gzip.decompress(compressed_record) == record_bytes
        assert base64.b64decode(envelope['data']) == compressed_record
        assert envelope['encoding'] == 'gzip-base64'
        assert len(record_bytes) == envelope['bytes']
        assert digest(record_bytes) == envelope['sha256'] == descriptor['recordSha256']
        assert record['source'] == report['source']
        assert record['seeds'] == provenance['seeds']
        assert record['nativeIdentity'] == descriptor['nativeIdentity']
        assert record['policyIdentity'] == descriptor['policyIdentity']
        fixture_bytes = (COPY / 'scripts/fixtures/pve-defender-assault' / descriptor['filename']).read_bytes()
        decoded = gzip.decompress(fixture_bytes)
        assert len(fixture_bytes) == descriptor['compressedBytes']
        assert digest(fixture_bytes) == descriptor['compressedSha256']
        assert len(decoded) == descriptor['checkpointBytes']
        assert digest(decoded) == descriptor['checkpointSha256']
        fixture = json.loads(decoded)
        assert fixture == record['final'] == json.loads(z.read(prefix + 'final.json'))
        assert fixture['state']['tickNumber'] == provenance['terminalTick'] == 108000
        assert fixture['state']['matchWinner'] == -1
        assert fixture['matchModeId'] == mode and fixture['matchModeVersion'] == 1
        assert all(next(u for u in fixture['state']['units'] if u['id'] == i)['hp'] > 0 for i in provenance['frontlineIds'])
        assert next(u for u in fixture['state']['units'] if u['id'] == provenance['defenderId'])['hp'] == 100
        checks.append({'mode': mode, 'nativeIdentity': record['nativeIdentity'], 'recordSha256': digest(record_bytes),
                       'compressedFixtureSha256': digest(fixture_bytes), 'decodedFixtureSha256': digest(decoded),
                       'fixtureEqualsOriginalFinalObjectWithoutNormalization': True})
    suite_log = z.read('suite.log').decode()
    assert '2711' in suite_log and '3600' in suite_log

copy_manifest = json.loads((COPY / 'review-source.json').read_text())
assert copy_manifest['source'] == HEAD
for row in copy_manifest['rows']:
    data = (COPY / row['path']).read_bytes()
    assert len(data) == row['bytes'] and digest(data) == row['sha256']
    assert data == subprocess.check_output(['git', 'show', f'{HEAD}:{row["path"]}'], cwd=REPO)
owned_diff = subprocess.check_output(['git', 'diff', '--name-only', BASE, HEAD], cwd=REPO, text=True).splitlines()
assert len(owned_diff) == 11
unchanged = ['scripts/pve-tiny-search-case.mjs', 'scripts/pve-tiny-search.test.mjs', 'scripts/pve-headless-fixture.mjs',
             'server.mjs', 'src/pve-opponent.mjs', 'src/gameplay-definitions.mjs']
for p in unchanged:
    assert subprocess.check_output(['git', 'show', f'{BASE}:{p}'], cwd=REPO) == subprocess.check_output(['git', 'show', f'{HEAD}:{p}'], cwd=REPO), p
for p in ['src/pve-skirmish-targets.mjs', 'scripts/pve-defender-assault.test.mjs']:
    assert subprocess.check_output(['git', 'show', f'c485aaee69ca018250becce24a5dda40ed77e22d:{p}'], cwd=REPO) == subprocess.check_output(['git', 'show', f'{HEAD}:{p}'], cwd=REPO), p
result = {'source': HEAD, 'base': BASE, 'archiveBytes': len(archive_bytes), 'archiveSha256': digest(archive_bytes),
          'archiveMembersVerified': 40, 'manifestEntriesVerified': 39, 'reportPassed': 1105, 'reportFailed': 1,
          'reportUnrun': 217, 'fixtures': checks, 'sourceCopyFilesVerified': len(copy_manifest['rows']),
          'ownedDiff': owned_diff, 'unchangedRuntimeAndFullTinyChecks': unchanged,
          'sourceCopyManifestSha256': digest((COPY / 'review-source.json').read_bytes())}
(OUT / 'provenance-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
