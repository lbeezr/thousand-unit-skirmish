import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root='/workspace/pve-67295aef-diagnosis-2026-10-05-evidence/exact-source-67295aef', out='/workspace/pve-67295aef-diagnosis-2026-10-05-evidence';
const {createPveHeadlessFixture}=await import(pathToFileURL(`${root}/scripts/pve-headless-fixture.mjs`));
const original=await import(pathToFileURL(`${root}/src/pve-opponent.mjs`));
const overlay=path.join(out,'priority-overlay'); await mkdir(overlay,{recursive:true});
const absolute=source=>source.replace(/from '(\.\/?[^']+)'/g,(_,name)=>`from '${pathToFileURL(path.resolve(root,'src',name)).href}'`);
let target=await readFile(`${root}/src/pve-skirmish-targets.mjs`,'utf8');
const before="candidates.push({ key: `unit:${identity(unit)}`, priority: 1, type: 'attack',";
assert.equal(target.split(before).length-1,1);
target=target.replace(before,"const immediate = unit.kind !== 'worker' && UNIT_DEFINITIONS[unit.kind].capabilities.includes('attack')\n      && soldiers.some(soldier => Math.hypot(unit.x - soldier.x, unit.z - soldier.z)\n        <= UNIT_DEFINITIONS[unit.kind].combat.range);\n    candidates.push({ key: `unit:${identity(unit)}`, priority: immediate ? -1 : 1, type: 'attack',");
await writeFile(`${overlay}/pve-skirmish-targets.mjs`,absolute(target));
let opponent=absolute(await readFile(`${root}/src/pve-opponent.mjs`,'utf8'));
opponent=opponent.replace(pathToFileURL(`${root}/src/pve-skirmish-targets.mjs`).href,pathToFileURL(`${overlay}/pve-skirmish-targets.mjs`).href);
await writeFile(`${overlay}/pve-opponent.mjs`,opponent);
const candidate=await import(pathToFileURL(`${overlay}/pve-opponent.mjs`));
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const summarize=(r,front)=>{
  const c=r.checkpoint(),s=c.state;
  return {tick:s.tickNumber,winner:s.matchWinner,banks:{food:s.teamFood,wood:s.teamWood},
    defender:s.units.find(u=>u.id===95)?.hp,frontline:s.units.filter(u=>front.includes(u.id)).map(u=>({id:u.id,hp:u.hp,x:u.x,z:u.z,lastAttack:u.lastAttackTick,unitTarget:u.attackTargetId,buildingTarget:u.attackBuildingTargetId})),
    townCenter:s.homeTownCenters[0].hp,
    living:s.units.filter(u=>u.hp>0).map(u=>({id:u.id,team:u.team,kind:u.kind,hp:u.hp})),
    queues:s.buildings.filter(b=>b.productionQueue?.length).map(b=>({id:b.id,queue:b.productionQueue}))};
};
const results=[];
for(const mode of ['authored','skirmish']) {
 const packet=JSON.parse(await readFile(`${out}/input/extracted/tiny-failure-evidence/tiny-${mode}-20260925-0/record.json`,'utf8'));
 for(const flavor of ['baseline','candidate']) for(const repeat of [0,1]) {
  const fixture=await createPveHeadlessFixture(packet.final.mapDefinition,packet.nativeIdentity),r=fixture.replay;
  try {
   r.restore(packet.final);
   const policies=[original.createDeterministicPolicy(packet.seeds[0],packet.policyIdentity),
     (flavor==='candidate'?candidate:original).createDeterministicPolicy(packet.seeds[1],packet.policyIdentity)];
   const observation=team=>original.toOpponentObservation(r.observe(team),team,packet.final.mapDefinition);
   const first=observation(1),front=first.units.friendly.filter(u=>u.hp>0 && u.kind!=='worker' && first.units.visibleEnemies.some(e=>e.hp>0 && e.kind!=='worker' && Math.hypot(e.x-u.x,e.z-u.z)<=3)).map(u=>u.id);
   assert.deepEqual(front,[80,82,86,92]);
   assert.ok(first.units.visibleEnemies.some(e=>e.id===95 && e.hp===100));
   const trace=[],samples=[summarize(r,front)];let defenderDeath=null;
   for(let i=0;i<1800;i++) {
    if(i%30===0) for(const team of [0,1]) {
     const v=observation(team);
     for(const command of policies[team].next(v)) {
      if(command.type==='attack') assert.ok(v.units.visibleEnemies.some(u=>u.id===command.targetId &&u.generation===command.targetGeneration &&u.hp>0));
      if(command.type==='attackBuilding') assert.ok(v.buildings.visibleEnemies.some(b=>b.id===command.buildingId &&b.hp>0));
      const notices=await r.order(team,command);r.drain();
      assert.ok(!notices.some(n=>/REJECTED|FAILED|UNREACHABLE/.test(n.message||'')),JSON.stringify({command,notices}));
      trace.push({tick:v.tick,team,command,notices});
     }
    }
    r.step(); if((i+1)%3===0 && defenderDeath===null && r.checkpoint().state.units.find(u=>u.id===95).hp<=0)defenderDeath=r.observe(0).tick; if((i+1)%150===0)samples.push(summarize(r,front));
   }
   const final=r.checkpoint();
   const result={mode,flavor,repeat,source:'67295aef1a744bde9000ce2c3d12e00b78a922e0',bound:1800,defenderDeath,initialHash:hash(packet.final),initialObservation:first,trace,samples,finalHash:hash(final)};
   await writeFile(`${out}/priority-${mode}-${flavor}-${repeat}.json`,JSON.stringify(result,null,2)+'\n');
   results.push(result);
   console.log(JSON.stringify({mode,flavor,repeat,firstCommands:trace.filter(t=>t.team===1).slice(0,4),initial:samples[0],end:samples.at(-1),finalHash:result.finalHash}));
  } finally {await fixture.dispose();}
 }
}
for(const mode of ['authored','skirmish'])for(const flavor of ['baseline','candidate']) {
 const pair=results.filter(r=>r.mode===mode&&r.flavor===flavor);assert.deepEqual(pair[0].trace,pair[1].trace);assert.equal(pair[0].finalHash,pair[1].finalHash);
}
await writeFile(`${out}/priority-summary.json`,JSON.stringify(results.map(r=>({mode:r.mode,flavor:r.flavor,repeat:r.repeat,initialHash:r.initialHash,finalHash:r.finalHash,initial:r.samples[0],end:r.samples.at(-1),defenderDeath:r.defenderDeath})),null,2)+'\n');
